
import React from 'react';
import { ShieldCheck, Scale, FileText, CheckCircle2, AlertTriangle, ExternalLink } from 'lucide-react';

interface ComplianceModalProps {
  onAcknowledge: () => void;
  clientName: string;
}

const ComplianceModal: React.FC<ComplianceModalProps> = ({ onAcknowledge, clientName }) => {
  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-500">
      <div className="bg-white rounded-[2rem] shadow-2xl w-full max-w-2xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-500 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-slate-900 p-8 text-white relative shrink-0">
          <div className="flex items-center gap-4 mb-2">
            <div className="p-3 bg-emerald-500/20 rounded-2xl border border-emerald-500/30">
              <ShieldCheck size={28} className="text-emerald-400" />
            </div>
            <div>
              <h3 className="text-2xl font-black uppercase tracking-tight">Statutory Disclosure</h3>
              <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mt-1">FAIS & POPIA Regulatory Alignment</p>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-8 overflow-y-auto space-y-8 custom-scrollbar">
          <div className="space-y-6">
            <section className="space-y-3">
              <div className="flex items-center gap-2 text-slate-900">
                <Scale size={16} className="text-indigo-500" />
                <h4 className="text-xs font-black uppercase tracking-widest">FAIS Act Notice</h4>
              </div>
              <p className="text-sm text-slate-600 leading-relaxed italic border-l-4 border-indigo-100 pl-4">
                "88 Wealth Management (operating under FAIS LICENSE NUMBER 9328 of Fairbairn Consult (PTY)LTD) is an Authorized Financial Services Provider. This application is an illustrative calculation tool and does not constitute formal financial advice as defined in the Financial Advisory and Intermediary Services Act (FAIS), 2002. No liability is accepted for decisions made based on these outputs without a formal signed Record of Advice."
              </p>
            </section>

            <section className="space-y-3">
              <div className="flex items-center gap-2 text-slate-900">
                <FileText size={16} className="text-emerald-500" />
                <h4 className="text-xs font-black uppercase tracking-widest">POPIA Data Protection</h4>
              </div>
              <p className="text-sm text-slate-600 leading-relaxed">
                By proceeding, you acknowledge that 88 Wealth Management will process data entered for the estate of <span className="font-bold text-slate-900 uppercase underline decoration-emerald-500/30">{clientName || 'The Client'}</span>. This processing is necessary to provide the requested estate planning illustrations.
              </p>
              <div className="bg-slate-50 p-4 rounded-xl space-y-2">
                <div className="flex items-start gap-2 text-[10px] font-bold text-slate-500 uppercase tracking-tight">
                  <CheckCircle2 size={12} className="text-emerald-500 shrink-0 mt-0.5" />
                  <span>Data is encrypted and hosted in secure environments.</span>
                </div>
                <div className="flex items-start gap-2 text-[10px] font-bold text-slate-500 uppercase tracking-tight">
                  <CheckCircle2 size={12} className="text-emerald-500 shrink-0 mt-0.5" />
                  <span>No information is sold to third parties.</span>
                </div>
                <div className="flex items-start gap-2 text-[10px] font-bold text-slate-500 uppercase tracking-tight">
                  <CheckCircle2 size={12} className="text-emerald-500 shrink-0 mt-0.5" />
                  <span>You retain the right to request deletion of your session data.</span>
                </div>
              </div>
            </section>

            <section className="bg-amber-50 border border-amber-100 p-5 rounded-2xl flex gap-4">
              <AlertTriangle className="text-amber-500 shrink-0" size={20} />
              <div>
                <h5 className="text-[10px] font-black uppercase tracking-widest text-amber-800 mb-1">Assumption Warning</h5>
                <p className="text-[11px] text-amber-700 leading-relaxed font-medium uppercase tracking-tight">
                  Calculations are based on current South African Revenue Service (SARS) tax tables. Future amendments to the Estate Duty Act or Income Tax Act may invalidate these results.
                </p>
              </div>
            </section>
          </div>

          <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-widest text-slate-400 border-t border-slate-100 pt-6">
            <a href="https://popia.co.za/" target="_blank" rel="noreferrer" className="flex items-center gap-1 hover:text-indigo-600 transition-colors">
              Privacy Statement <ExternalLink size={10} />
            </a>
            <span>Version 1.4.2-COMPLY</span>
          </div>
        </div>

        {/* Footer */}
        <div className="p-8 bg-slate-50 border-t border-slate-100 shrink-0">
          <button 
            onClick={onAcknowledge}
            className="w-full bg-slate-950 hover:bg-slate-800 text-white font-black uppercase tracking-widest py-5 rounded-2xl transition-all shadow-xl shadow-slate-900/20 flex items-center justify-center gap-3"
          >
            Acknowledge & Enter Suite
          </button>
        </div>
      </div>
    </div>
  );
};

export default ComplianceModal;

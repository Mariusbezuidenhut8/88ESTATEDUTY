
// Fix: cast Object.values to number[] and property access to number to resolve unknown operator errors
import React from 'react';
import { 
  Farm, 
  LivestockState, 
  MiscellaneousState, 
  BusinessInterestsState, 
  ResidentialState,
  VehicleState,
  CashState,
  InvestmentState,
  LoanAccountState,
  OtherState,
  PolicyState,
  DeductionState,
  Art4qState,
  ResiduePageState
} from '../types';
// Fix: Added 'Info' to the imports from lucide-react to resolve the error on line 170
import { FileText, Share2, ShieldCheck, TrendingUp, Scale, AlertCircle, Download, Lightbulb, Zap, ArrowRightCircle, Target, Coins, CheckCircle2, Info } from 'lucide-react';

interface SummaryPageProps {
  clientName: string;
  farms: Farm[];
  livestock: LivestockState;
  misc: MiscellaneousState;
  business: BusinessInterestsState;
  residential: ResidentialState;
  vehicles: VehicleState;
  cash: CashState;
  investments: InvestmentState;
  loans: LoanAccountState;
  other: OtherState;
  policies: PolicyState;
  deductions: DeductionState;
  art4q: Art4qState;
  residueState: ResiduePageState;
  art4aRebate: number;
  autoExecutorsFee: number;
  totalCalculatedCGT: number;
  grossEstate: number;
  netEstate: number;
  taxableEstate: number;
  estateDuty: number;
  accrualClaim: number;
}

const SummaryPage: React.FC<SummaryPageProps> = ({
  clientName,
  farms,
  livestock,
  misc,
  business,
  residential,
  vehicles,
  cash,
  investments,
  loans,
  other,
  policies,
  deductions,
  art4q,
  residueState,
  art4aRebate,
  autoExecutorsFee,
  totalCalculatedCGT,
  grossEstate,
  netEstate,
  taxableEstate,
  estateDuty,
  accrualClaim
}) => {
  const formatCurrency = (num: number) => {
    return num.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const handlePrint = () => {
    const originalTitle = document.title;
    const dateStr = new Date().toISOString().split('T')[0];
    document.title = `88WM_Estate_Report_${clientName.replace(/\s+/g, '_')}_${dateStr}`;
    window.print();
    setTimeout(() => { document.title = originalTitle; }, 500);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `88 Wealth Management | Estate of ${clientName}`,
          text: `Estate Liquidity Analysis for ${clientName}.\nGross Estate: R ${formatCurrency(grossEstate)}\nNet Capital: R ${formatCurrency(netEstate)}\nEstate Duty: R ${formatCurrency(estateDuty)}`,
          url: window.location.href,
        });
      } catch (error) { console.error('Error sharing:', error); }
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('Share link copied to clipboard!');
    }
  };

  const LandmarkIcon = ({ className, size }: { className?: string, size?: number }) => (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      width={size || 24} 
      height={size || 24} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      className={className}
    >
      <line x1="3" y1="22" x2="21" y2="22"></line>
      <line x1="6" y1="18" x2="6" y2="11"></line>
      <line x1="10" y1="18" x2="10" y2="11"></line>
      <line x1="14" y1="18" x2="14" y2="11"></line>
      <line x1="18" y1="18" x2="18" y2="11"></line>
      <polygon points="12 2 20 7 4 7 12 2"></polygon>
    </svg>
  );

  const totalFarmsMarket = farms.reduce((sum, f) => sum + (f.marketValue || 0), 0);
  const totalFarmsSARS = farms.reduce((sum, f) => sum + (f.marketValue || 0) * 0.7, 0);
  // Fix: cast Object.values to number[] to resolve unknown operator errors
  const totalLivestock = (Object.values(livestock) as number[]).reduce((a, b) => a + (b || 0), 0);
  const totalBusiness = (business.soleProprietorship || 0) + (business.partnership || 0) + (business.ccInterest || 0) + (business.companyShares || 0);
  const totalResidential = (residential.property1 || 0) + (residential.property2 || 0) + (residential.holidayHome || 0) + (residential.householdEffects || 0);
  const totalVehicles = (vehicles.v1.value || 0) + (vehicles.v2.value || 0) + (vehicles.v3.value || 0);
  const totalCashAssets = (cash.onCall || 0) + (cash.moneyMarket || 0);
  const totalInvestments = (investments.shares || 0) + (investments.unitTrusts || 0);
  const totalLoans = (loans.creditLoans || 0);
  const totalOtherSub = (other.o1.value || 0) + (other.o2.value || 0) + (other.o3.value || 0) + (other.o4.value || 0) + (other.o5.value || 0);

  const totalAssetsSARS = totalFarmsSARS + totalLivestock + totalBusiness + totalResidential + totalVehicles + totalCashAssets + totalInvestments + totalLoans + totalOtherSub;
  const totalLiabilities = autoExecutorsFee + totalCalculatedCGT + deductions.mastersFees + deductions.liabilities + deductions.funeral + deductions.debitLoans + accrualClaim;
  
  const spouseBequestsFromArt4q = (art4q.usufruct || 0) + (art4q.vehicles || 0) + (art4q.miscValue || 0) + (art4q.residential || 0) + (art4q.household || 0) + (art4q.other || 0);
  const totalSec4q = policies.spouse + residueState.spouseLegacy + spouseBequestsFromArt4q;

  // Strategic Insights Logic
  const insights = [];
  const totalAvailableLiquidity = totalCashAssets + policies.estate + policies.ceded;
  const totalCashRequired = totalLiabilities + estateDuty;
  const cashDeficit = Math.max(0, totalCashRequired - totalAvailableLiquidity);

  if (cashDeficit > 0) {
    insights.push({
      title: "Critical Liquidity Shortfall",
      description: `The estate requires R ${formatCurrency(cashDeficit)} in additional liquid funds. This shortfall may force a sale of capital assets like farms or business interests at potentially non-market prices to settle SARS and creditors.`,
      impact: "HIGH",
      icon: Zap,
      category: "Liquidity"
    });
  } else {
    insights.push({
      title: "Positive Liquidity Buffer",
      description: `The estate appears to be liquid. Current cash and policy proceeds are sufficient to settle all projected liabilities without asset disruption.`,
      impact: "LOW",
      icon: CheckCircle2,
      category: "Liquidity"
    });
  }

  // Check if SARS 20% rule is being used (if any major asset has 0 base cost)
  const isUsing20PercentRule = farms.some(f => f.baseCost === 0) || residential.property1Base === 0 || business.soleProprietorshipBase === 0;
  if (isUsing20PercentRule) {
    insights.push({
      title: "SARS 20% Rule Election",
      description: "Certain assets are utilizing the 20% statutory base cost rule. While convenient, this might result in higher CGT than using the Valuation Date (2001) method or actual expenditure records. Optimization is recommended.",
      impact: "MEDIUM",
      icon: Info,
      category: "Tax Efficiency"
    });
  }

  if (totalCalculatedCGT > estateDuty) {
    insights.push({
      title: "CGT Dominance",
      description: `Capital Gains Tax (R ${formatCurrency(totalCalculatedCGT)}) is currently a larger liability than Estate Duty. This highlights a high degree of capital appreciation in the portfolio and potential for base-cost restructuring.`,
      impact: "MEDIUM",
      icon: TrendingUp,
      category: "Tax Strategy"
    });
  }

  if (autoExecutorsFee > (grossEstate * 0.03)) {
    insights.push({
      title: "Executor Remuneration Impact",
      description: `Statutory fees of R ${formatCurrency(autoExecutorsFee)} represent a significant estate drain. There may be room for negotiation or the use of alternate structures for non-complex assets to preserve family wealth.`,
      impact: "MEDIUM",
      icon: Coins,
      category: "Admin Fees"
    });
  }

  if (totalFarmsMarket > (grossEstate * 0.5)) {
    insights.push({
      title: "Asset Concentration Risk",
      description: `Agricultural property accounts for more than half of your gross wealth. While Section 1(1) provides a duty discount, the estate's overall health is highly sensitive to land valuation volatility.`,
      impact: "MEDIUM",
      icon: LandmarkIcon,
      category: "Asset Allocation"
    });
  }

  if (accrualClaim > 0) {
    insights.push({
      title: "Accrual Balancing Claim",
      description: `An accrual claim of R ${formatCurrency(accrualClaim)} effectively shifts wealth between spouses tax-free, significantly lowering the taxable estate of the first-dying. This remains a vital planning pillar.`,
      impact: "LOW",
      icon: Scale,
      category: "Matrimonial"
    });
  }

  const Row = ({ label, markVal, sarsVal, note }: { label: string, markVal?: number, sarsVal?: number, note?: string }) => (
    <div className="grid grid-cols-12 gap-2 py-2 border-b border-slate-50 items-center text-[11px] sm:text-sm group transition-colors hover:bg-slate-50/50">
      <div className="col-span-5 text-slate-700 font-semibold">{label}</div>
      <div className="col-span-3 text-right font-mono text-slate-400">
        {markVal !== undefined ? `R ${formatCurrency(markVal)}` : ''}
      </div>
      <div className="col-span-3 text-right font-mono font-black text-slate-900">
        {sarsVal !== undefined ? `R ${formatCurrency(sarsVal)}` : ''}
      </div>
      <div className="col-span-1 text-right text-emerald-600 font-black text-[9px]">{note}</div>
    </div>
  );

  const SectionHeader = ({ title, markLabel = "Market Value", sarsLabel = "SARS Value" }: { title: string, markLabel?: string, sarsLabel?: string }) => (
    <div className="grid grid-cols-12 gap-2 mt-8 mb-2 border-b-2 border-slate-900 items-end pb-2">
      <div className="col-span-5 text-[10px] font-black uppercase tracking-[0.2em] text-slate-900">{title}</div>
      <div className="col-span-3 text-right text-[8px] font-black uppercase text-slate-400 tracking-widest">{markLabel}</div>
      <div className="col-span-3 text-right text-[8px] font-black uppercase text-slate-400 tracking-widest">{sarsLabel}</div>
      <div className="col-span-1 text-right text-[8px] font-black uppercase text-slate-400 tracking-widest">REF</div>
    </div>
  );

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-32 max-w-full">
      <div className="flex flex-col sm:flex-row justify-between items-center print:hidden bg-slate-950 p-6 rounded-2xl shadow-xl border border-slate-800 gap-6">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-emerald-500/20 rounded-xl text-emerald-400">
            <ShieldCheck size={28} />
          </div>
          <div>
            <h3 className="text-white font-black uppercase tracking-tight text-lg leading-none">Estate Report Sheet</h3>
            <p className="text-slate-500 text-[10px] mt-1 font-bold uppercase tracking-widest">Annexure A • {clientName || 'Untitled'}</p>
          </div>
        </div>
        <div className="flex gap-4 w-full sm:w-auto">
          <button 
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 bg-slate-800 text-slate-300 border border-slate-700 px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] hover:bg-slate-700 transition-all active:scale-95" 
            onClick={handleShare}
          >
            <Share2 size={16} /> Share Link
          </button>
          <button 
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 bg-emerald-600 text-white px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-[0.2em] hover:bg-emerald-500 shadow-lg shadow-emerald-500/20 transition-all active:scale-95" 
            onClick={handlePrint}
          >
            <Download size={16} /> Export PDF
          </button>
        </div>
      </div>

      {/* Report Sheet */}
      <div className="bg-white shadow-[0_0_100px_-15px_rgba(0,0,0,0.1)] border border-slate-200 p-6 sm:p-20 max-w-[210mm] mx-auto min-h-[297mm] print:shadow-none print:border-none print:p-0 print:mx-0 print:w-full overflow-hidden">
        <div className="flex justify-between items-start border-b-[4px] border-slate-900 pb-8 mb-10">
          <div className="flex items-center gap-6">
            <div className="flex flex-col">
              <span className="text-3xl font-black tracking-tighter text-slate-900">88 WEALTH</span>
              <span className="text-[10px] font-bold tracking-[0.3em] text-slate-400 uppercase">MANAGEMENT</span>
            </div>
          </div>
          <div className="text-right flex flex-col items-end">
             <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest leading-tight">
                Ref: 88WM-ED-{new Date().getFullYear()}
             </div>
             <div className="text-[8px] font-medium text-slate-400 italic mt-1">
                FSP License 9328
             </div>
          </div>
        </div>

        <div className="mb-10">
          <h2 className="text-4xl font-black uppercase tracking-tighter mb-2 text-slate-900">ANNEXURE A</h2>
          <div className="space-y-1 text-[10px] font-black uppercase tracking-[0.1em] text-slate-500">
            <p>Estate of: <span className="text-slate-950 ml-2 border-b border-slate-200">{clientName}</span></p>
            <p>Subject: Assets & Liabilities Summary (Illustrative)</p>
          </div>
        </div>

        <SectionHeader title="Capital Assets" />
        <Row label="Agricultural Property (Farms)" markVal={totalFarmsMarket} sarsVal={totalFarmsSARS} note="(1)" />
        <Row label="Livestock & Game Assets" markVal={totalLivestock} sarsVal={totalLivestock} note="(1)" />
        <Row label="Business Interests & CC Equity" markVal={totalBusiness} sarsVal={totalBusiness} note="(1)" />
        <Row label="Residential Real Estate Portfolio" markVal={totalResidential} sarsVal={totalResidential} note="(1)" />
        <Row label="Motor Vehicle Inventory" markVal={totalVehicles} sarsVal={totalVehicles} note="(1)" />
        <Row label="Equity Investments & Unit Trusts" markVal={totalInvestments} sarsVal={totalInvestments} />
        <Row label="Cash & Call Accounts" markVal={totalCashAssets} sarsVal={totalCashAssets} />
        <Row label="Loan Accounts (Debit)" markVal={totalLoans} sarsVal={totalLoans} />
        <Row label="Miscellaneous Personal Assets" markVal={totalOtherSub} sarsVal={totalOtherSub} />
        
        <div className="grid grid-cols-12 gap-2 py-4 items-center border-t-2 border-slate-900 mt-2">
          <div className="col-span-5 text-[10px] font-black uppercase tracking-[0.1em]">Aggregate Assets (SARS Value)</div>
          <div className="col-span-3"></div>
          <div className="col-span-3 text-right font-mono font-black text-slate-950 text-base">R {formatCurrency(totalAssetsSARS)}</div>
        </div>

        <SectionHeader title="Life Insurance & Nominated Policies" />
        <Row label="Nominated to Surviving Spouse" sarsVal={policies.spouse} note="(2)" />
        <Row label="Payable to Estate" sarsVal={policies.estate} note="(2)" />
        <Row label="Nominated to Third Parties" sarsVal={policies.thirdParties} note="(2)" />
        {/* Fix: Explicitly cast property access to number to resolve unknown assignment errors */}
        <Row label="Death Values (Outside Policies)" sarsVal={(policies.deathValuesSpouse as number) + (policies.deathValues3rd as number)} />
        
        <div className="grid grid-cols-12 gap-2 py-10 items-center bg-slate-900 -mx-10 px-10 my-8 text-white">
          <div className="col-span-8">
            <h3 className="text-xl font-black uppercase tracking-tight">Total Gross Estate</h3>
            <p className="text-slate-500 text-[9px] font-bold uppercase tracking-widest mt-1">Determined for Section 3(2) purposes</p>
          </div>
          <div className="col-span-4 text-right font-mono font-black text-2xl text-emerald-400">R {formatCurrency(grossEstate)}</div>
        </div>

        <SectionHeader title="Liabilities & Deductions" markLabel="" sarsLabel="" />
        <Row label="Accrual Claim (ANC with Accrual)" sarsVal={accrualClaim} note="(3)" />
        <Row label="Executor's Remuneration (Statutory)" sarsVal={autoExecutorsFee} />
        <Row label="Master's Fees & Funeral Costs" sarsVal={deductions.mastersFees + deductions.funeral} />
        <Row label="General Estate Liabilities" sarsVal={deductions.liabilities} />
        <Row label="Projected Capital Gains Tax (CGT)" sarsVal={totalCalculatedCGT} note="(4)" />
        <Row label="Section 4(q) Spousal Bequests" sarsVal={totalSec4q} note="(5)" />

        <div className="mt-12 space-y-2 border-t-2 border-slate-900 pt-6">
          <div className="grid grid-cols-12 gap-2 items-center">
            <div className="col-span-8 text-[11px] font-black uppercase tracking-tight text-slate-500">Net Value for Estate Duty</div>
            <div className="col-span-4 text-right font-mono font-black text-lg text-slate-900">R {formatCurrency(netEstate)}</div>
          </div>
          <div className="grid grid-cols-12 gap-2 items-center bg-emerald-600 rounded-xl py-6 px-8 text-white shadow-lg">
             <div className="col-span-8">
                <h2 className="text-2xl font-black uppercase tracking-tighter">Estate Duty Liability</h2>
                <p className="text-emerald-100 text-[9px] font-black uppercase tracking-widest mt-1">Final SARS Assessment</p>
             </div>
             <div className="col-span-4 text-right font-mono font-black text-3xl">R {formatCurrency(estateDuty)}</div>
          </div>
        </div>

        {/* STRATEGIC INSIGHTS SECTION */}
        <div className="mt-16 border-t-4 border-slate-100 pt-10 break-inside-avoid">
          <div className="flex items-center gap-3 mb-6">
             <Lightbulb className="text-emerald-600" size={24}/>
             <h3 className="text-xl font-black uppercase tracking-tighter text-slate-900">Strategic Insights</h3>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {insights.map((insight, idx) => (
              <div key={idx} className="bg-slate-50 border border-slate-100 rounded-2xl p-5 relative overflow-hidden flex flex-col justify-between">
                <div className={`absolute top-0 left-0 w-1 h-full ${insight.impact === 'HIGH' ? 'bg-red-500' : insight.impact === 'MEDIUM' ? 'bg-indigo-500' : 'bg-emerald-500'}`} />
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[8px] font-black uppercase tracking-widest text-slate-400">{insight.category}</span>
                    <insight.icon size={16} className={`${insight.impact === 'HIGH' ? 'text-red-500' : insight.impact === 'MEDIUM' ? 'text-indigo-500' : 'text-emerald-500'}`} />
                  </div>
                  <h4 className="text-[10px] font-black uppercase tracking-tight text-slate-900 mb-1">{insight.title}</h4>
                  <p className="text-[10px] text-slate-500 leading-relaxed line-clamp-3">
                    {insight.description}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-8 bg-slate-900 rounded-2xl p-6 text-white flex flex-col sm:flex-row items-center justify-between gap-4">
             <div className="flex items-center gap-3">
                <Target size={20} className="text-emerald-400" />
                <p className="text-[10px] font-bold uppercase tracking-tight">Review these insights with your 88 Wealth Management Advisor.</p>
             </div>
             <div className="text-[9px] font-black uppercase tracking-widest px-4 py-2 border border-white/20 rounded-full">
                Strictly Illustrative
             </div>
          </div>
        </div>

        <div className="mt-12 p-6 bg-slate-50 border border-slate-200 rounded-2xl">
           <p className="text-[8px] text-slate-400 text-justify leading-relaxed uppercase tracking-widest">
              FAIS DISCLOSURE: 88 Wealth Management (FSP 9328) provides this report for illustrative purposes only. This calculation does not constitute financial advice as defined in the FAIS Act. Users are encouraged to verify all figures with a qualified estate professional.
           </p>
        </div>

        <div className="mt-12 pt-8 flex justify-between items-end border-t border-slate-100">
           <div className="flex flex-col gap-1">
              <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Signed on behalf of 88WM</span>
              <div className="w-32 h-8 border-b border-slate-200" />
           </div>
           <div className="text-right">
              <p className="text-[9px] font-black text-slate-900 uppercase tracking-widest">{new Date().toLocaleDateString('en-ZA', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default SummaryPage;

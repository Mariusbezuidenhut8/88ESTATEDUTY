
import React, { useState } from 'react';
import { Page, AccessRole } from '../types';
import { 
  LayoutDashboard, Coins, Calculator, Receipt, Users, 
  FileCheck, Landmark, PiggyBank, BookOpen, ShieldAlert, 
  LogOut, ShieldCheck, Scale, Menu, X 
} from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  currentPage: Page;
  onPageChange: (page: Page) => void;
  clientName: string;
  onClientNameChange: (name: string) => void;
  role: AccessRole;
  onLogout: () => void;
}

const Layout: React.FC<LayoutProps> = ({ 
  children, 
  currentPage, 
  onPageChange, 
  clientName, 
  onClientNameChange,
  role,
  onLogout
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { name: Page.EstateDuty, icon: Calculator },
    { name: Page.ExecutorsFees, icon: Receipt },
    { name: Page.CGT, icon: Landmark },
    { name: Page.Cash, icon: Coins },
    // Fix: Using correct Page enum values 'Remains' and 'Aanwas' as defined in types.ts
    { name: Page.Remains, icon: PiggyBank },
    { name: Page.Aanwas, icon: Users },
    { name: Page.Appropriation, icon: LayoutDashboard },
    { name: Page.Summary, icon: FileCheck },
    { name: Page.UserManual, icon: BookOpen },
  ];

  if (role === 'ADMIN') {
    navItems.push({ name: Page.Admin, icon: ShieldAlert });
  }

  const handlePageSelect = (page: Page) => {
    onPageChange(page);
    setIsMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-slate-50 font-sans text-slate-900">
      {/* Mobile Top Bar */}
      <div className="md:hidden bg-slate-950 text-white p-4 flex justify-between items-center sticky top-0 z-[60] shadow-lg">
        <div className="flex flex-col">
          <span className="text-lg font-black tracking-tighter">88 WEALTH</span>
          <span className="text-[8px] font-medium tracking-[0.3em] text-slate-500 uppercase -mt-1">MANAGEMENT</span>
        </div>
        <button 
          onClick={() => setIsMobileMenuOpen(true)}
          className="p-2 bg-slate-900 rounded-lg text-emerald-400 active:scale-95 transition-transform"
        >
          <Menu size={24} />
        </button>
      </div>

      {/* Sidebar / Mobile Drawer */}
      <aside className={`
        fixed inset-y-0 left-0 z-[70] w-80 bg-slate-950 text-white flex flex-col shadow-2xl transition-transform duration-300 ease-out transform
        ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
        md:translate-x-0 md:sticky md:h-screen
      `}>
        {/* Drawer Header (Logo + Close Button) */}
        <div className="p-6 border-b border-slate-800 relative">
          <button 
            onClick={() => setIsMobileMenuOpen(false)}
            className="md:hidden absolute top-6 right-6 p-2 bg-slate-900 rounded-xl text-slate-400 hover:text-white"
          >
            <X size={20} />
          </button>
          
          <div className="flex flex-col gap-4 pr-10 md:pr-0">
            <div className="flex flex-col items-start">
              <div className="flex items-baseline gap-1">
                <span className="text-3xl font-black tracking-tighter text-white">88 WEALTH</span>
              </div>
              <span className="text-xs font-medium tracking-[0.4em] text-slate-500 uppercase -mt-1">MANAGEMENT</span>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="w-px h-10 bg-slate-800" />
              <p className="text-[9px] leading-tight text-slate-500 italic">
                operating under the FSP license<br/>
                number 9328 of Fairbairn Consult<br/>
                (Pty) Ltd
              </p>
            </div>
          </div>
        </div>
        
        {/* Navigation Items */}
        <nav className="flex-1 py-6 overflow-y-auto space-y-1 px-4 custom-scrollbar">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.name;
            return (
              <button
                key={item.name}
                onClick={() => handlePageSelect(item.name)}
                className={`w-full flex items-center gap-3 px-4 py-3.5 text-xs font-black uppercase tracking-widest transition-all duration-200 rounded-xl ${
                  isActive 
                    ? 'bg-emerald-600/15 text-emerald-400 border border-emerald-500/30 shadow-lg shadow-emerald-500/5' 
                    : 'text-slate-500 hover:text-white hover:bg-white/5'
                }`}
              >
                <Icon size={18} className={isActive ? 'text-emerald-400' : 'text-slate-600'} />
                {item.name}
              </button>
            );
          })}
        </nav>
        
        {/* Footer Area */}
        <div className="p-6 mt-auto border-t border-slate-900 space-y-4 bg-slate-950/50 backdrop-blur-md">
           <div className="bg-slate-900/50 p-4 rounded-xl border border-slate-800/50 flex items-center justify-between">
              <div>
                <span className="text-[9px] text-slate-500 font-bold uppercase tracking-widest block mb-0.5">Role</span>
                <span className={`text-[10px] font-black ${role === 'ADMIN' ? 'text-indigo-400' : 'text-emerald-400'}`}>{role}</span>
              </div>
              <ShieldCheck size={16} className="text-slate-700" />
           </div>
           
           <button 
             onClick={onLogout}
             className="w-full flex items-center justify-center gap-2 px-4 py-3 text-[10px] font-black uppercase tracking-widest bg-red-600/10 text-red-500 border border-red-500/20 rounded-xl hover:bg-red-600 hover:text-white transition-all active:scale-95"
           >
              <LogOut size={14} /> Log Out Securely
           </button>
        </div>
      </aside>

      {/* Backdrop for mobile drawer */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[65] md:hidden animate-in fade-in duration-300"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 min-h-screen">
        <header className="bg-white/80 backdrop-blur-md sticky top-0 z-30 border-b border-slate-200 px-4 md:px-8 py-4 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex flex-col w-full sm:w-auto">
            <h2 className="text-lg md:text-xl font-black text-slate-900 uppercase tracking-tight">{currentPage}</h2>
            <div className="flex items-center gap-2 mt-1">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <p className="text-[10px] text-slate-400 uppercase tracking-[0.2em] font-black">Calculation Suite • Verified Session</p>
            </div>
          </div>
          
          <div className="flex items-center gap-6 w-full sm:w-auto">
            <div className="h-10 w-px bg-slate-200 hidden sm:block" />
            <div className="text-left w-full sm:w-auto">
              <label className="text-[9px] text-slate-400 uppercase font-black block tracking-widest mb-1">Estate Beneficiary</label>
              <input
                type="text"
                value={clientName}
                onChange={(e) => onClientNameChange(e.target.value)}
                placeholder="Client Name..."
                className="w-full text-slate-900 font-black bg-transparent border-b-2 border-emerald-500/30 focus:outline-none focus:border-emerald-500 px-2 py-0.5 text-sm transition-all placeholder:text-slate-200 uppercase"
              />
            </div>
          </div>
        </header>

        <div className="p-4 md:p-8 lg:p-12 max-w-7xl mx-auto w-full flex-1">
          {children}
        </div>

        {/* Regulatory Footer */}
        <footer className="px-8 py-6 bg-slate-100 border-t border-slate-200 text-slate-400 shrink-0 print:hidden mt-auto">
          <div className="max-w-7xl mx-auto flex flex-col lg:flex-row justify-between items-center gap-6 text-center lg:text-left">
            <div className="flex items-center gap-4 flex-col lg:flex-row">
              <Scale size={20} className="text-slate-300 hidden lg:block" />
              <p className="text-[10px] font-medium leading-relaxed max-w-2xl">
                <span className="font-black text-slate-500 uppercase tracking-widest mr-1">FAIS DISCLOSURE:</span>
                This suite is for illustrative purposes. 88 Wealth Management (operating under FAIS LICENSE NUMBER 9328 of Fairbairn Consult (PTY)LTD) is an Authorised FSP. Calculations should be verified by a qualified Tax Practitioner or Estate Planner. 
                <span className="font-black text-slate-500 uppercase tracking-widest ml-2 mr-1">POPIA:</span>
                Personal data is processed in line with our Data Privacy Policy.
              </p>
            </div>
            <div className="flex items-center gap-6 flex-col lg:flex-row">
              <span className="text-[9px] font-black uppercase tracking-widest lg:border-r lg:border-slate-200 lg:pr-6">© 2025 88 Wealth Management</span>
              <div className="flex items-center gap-2">
                 <ShieldCheck size={14} className="text-emerald-500/50" />
                 <span className="text-[9px] font-black uppercase tracking-[0.2em]">RSA Regulated Entity</span>
              </div>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
};

export default Layout;

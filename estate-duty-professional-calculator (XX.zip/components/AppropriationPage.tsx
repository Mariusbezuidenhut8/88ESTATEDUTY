
import React from 'react';
import { AppropriationPageState, AppropriationParty } from '../types';
import { Users, Info, Calculator, Lock, Percent, ArrowRight, PieChart, Link as LinkIcon } from 'lucide-react';

interface AppropriationPageProps {
  clientName: string;
  totalEstateDuty: number;
  netEstateValue: number;
  appropriationState: AppropriationPageState;
  setAppropriationState: React.Dispatch<React.SetStateAction<AppropriationPageState>>;
}

const AppropriationPage: React.FC<AppropriationPageProps> = ({
  clientName,
  totalEstateDuty,
  netEstateValue,
  appropriationState,
  setAppropriationState
}) => {
  const formatCurrency = (num: number) => {
    return num.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 });
  };

  const handlePartyChange = (id: string, field: keyof AppropriationParty, val: string) => {
    setAppropriationState(prev => ({
      ...prev,
      parties: prev.parties.map(p => {
        if (p.id !== id) return p;
        if (field === 'name') return { ...p, name: val };
        const numericVal = val.replace(/[^0-9.]/g, '');
        return { ...p, portion: numericVal === '' ? 0 : parseFloat(numericVal) };
      })
    }));
  };

  const calculateDutyForParty = (portion: number) => {
    if (netEstateValue <= 0) return 0;
    return (portion / netEstateValue) * totalEstateDuty;
  };

  const totalApportionedDuty = appropriationState.parties.reduce((sum, p) => sum + calculateDutyForParty(p.portion), 0);

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-32">
      {/* Header Panel */}
      <div className="bg-slate-800 rounded-xl p-6 shadow-lg border-b-4 border-slate-600 text-white flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-black uppercase tracking-tight">Appropriation (Aanspreeklikheid)</h2>
          <p className="text-slate-400 text-xs font-medium uppercase tracking-widest mt-1">Duty Liability for 3rd Parties</p>
        </div>
        <div className="text-right">
          <span className="text-slate-400 font-bold uppercase text-[10px] block tracking-widest mb-1">Estate</span>
          <span className="text-xl font-black uppercase border-b-2 border-slate-500/30 pb-1">{clientName || 'Unknown'}</span>
        </div>
      </div>

      {/* ESTATE SUMMARY FOR APPORTIONMENT */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-indigo-50/50 rounded-2xl border border-indigo-100 p-8 shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-indigo-100 rounded-xl text-indigo-600">
              <Calculator size={24} />
            </div>
            <div>
              <span className="text-indigo-900 font-black uppercase text-[10px] tracking-tight block">Boedelbelasting betaalbaar</span>
              <span className="text-indigo-600 font-black text-[8px] uppercase tracking-widest flex items-center gap-1 mt-1">
                <LinkIcon size={10}/> Synced Total Duty
              </span>
            </div>
          </div>
          <div className="text-3xl font-mono font-black text-indigo-700">R {formatCurrency(totalEstateDuty)}</div>
        </div>

        <div className="bg-indigo-50/50 rounded-2xl border border-indigo-100 p-8 shadow-sm">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-indigo-100 rounded-xl text-indigo-600">
              <PieChart size={24} />
            </div>
            <div>
              <span className="text-indigo-900 font-black uppercase text-[10px] tracking-tight block">Netto boedel</span>
              <span className="text-indigo-600 font-black text-[8px] uppercase tracking-widest flex items-center gap-1 mt-1">
                <LinkIcon size={10}/> Synced Net Value
              </span>
            </div>
          </div>
          <div className="text-3xl font-mono font-black text-indigo-700">R {formatCurrency(netEstateValue)}</div>
        </div>
      </div>

      {/* PARTIES GRID */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="bg-slate-900 p-4 text-white font-black uppercase text-[11px] tracking-[0.2em] grid grid-cols-1 md:grid-cols-12 gap-4 text-center">
          <div className="md:col-span-4 text-left px-2">Party / Beneficiary</div>
          <div className="md:col-span-3">Portion (Gedeelte)</div>
          <div className="md:col-span-1 flex justify-center items-center">
             <Percent size={14} className="text-slate-500" />
          </div>
          <div className="md:col-span-4 bg-red-600/20 rounded-md py-1">Duty Payable (deur 3de)</div>
        </div>

        <div className="divide-y divide-slate-100 p-2">
          {appropriationState.parties.map((party, idx) => {
            const duty = calculateDutyForParty(party.portion);
            const percentage = netEstateValue > 0 ? (party.portion / netEstateValue) * 100 : 0;
            
            return (
              <div key={party.id} className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center p-4 hover:bg-slate-50 transition-colors group">
                {/* Party Name */}
                <div className="md:col-span-4 flex items-center gap-4">
                  <span className="text-slate-300 font-black text-xs">{idx + 1}.</span>
                  <input
                    type="text"
                    value={party.name}
                    onChange={(e) => handlePartyChange(party.id, 'name', e.target.value)}
                    placeholder={`Party ${idx + 1}`}
                    className="flex-1 bg-transparent border-none focus:ring-0 font-bold text-slate-700 placeholder:text-slate-200 text-sm uppercase"
                  />
                </div>

                {/* Portion Input */}
                <div className="md:col-span-3 relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300 font-mono text-xs">R</span>
                  <input
                    type="text"
                    inputMode="numeric"
                    value={party.portion === 0 ? '' : party.portion.toLocaleString().replace(/,/g, '')}
                    onChange={(e) => handlePartyChange(party.id, 'portion', e.target.value)}
                    placeholder="0"
                    className="w-full bg-white border border-slate-200 rounded-lg pl-7 pr-3 py-2 text-right font-mono font-bold text-slate-800 focus:ring-2 focus:ring-emerald-500/20 outline-none"
                  />
                </div>

                {/* Percentage Indicator */}
                <div className="md:col-span-1 text-center">
                  <span className="text-[10px] font-mono font-bold text-slate-400">
                    {percentage.toFixed(2)}%
                  </span>
                </div>

                {/* Calculated Liability */}
                <div className="md:col-span-4 flex items-center justify-between bg-slate-50 rounded-lg px-4 py-2 border border-slate-100">
                  <ArrowRight size={14} className="text-slate-200" />
                  <span className="font-mono font-black text-red-600 text-lg">
                    R {formatCurrency(duty)}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* TOTAL APPORTIONED PANEL */}
      <div className="bg-slate-900 rounded-2xl p-10 flex flex-col items-center justify-center shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 p-4 opacity-10 pointer-events-none">
           <Users size={120} />
        </div>
        <div className="text-emerald-500 text-[10px] font-black uppercase tracking-[0.4em] mb-4">
          Totale Aanspreeklikheid
        </div>
        <div className="text-7xl font-mono font-black text-white drop-shadow-lg text-center">
          R {formatCurrency(totalApportionedDuty)}
        </div>
        <div className="mt-8 flex items-center gap-4 bg-white/5 px-8 py-3 rounded-full border border-white/10">
           <Info size={18} className="text-red-400" />
           <span className="text-slate-400 font-black uppercase text-xs tracking-widest">
              Sum of individual apportionments should not exceed total estate duty
           </span>
        </div>
      </div>
    </div>
  );
};

export default AppropriationPage;

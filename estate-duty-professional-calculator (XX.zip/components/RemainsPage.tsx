
import React from 'react';
import { ResiduePageState, Legacy } from '../types';
import { Plus, Trash2, Calculator, Info, Lock, ArrowDown, User, Heart, AlertCircle, CheckCircle, Link as LinkIcon } from 'lucide-react';

interface RemainsPageProps {
  clientName: string;
  netAssetsAvailable: number;
  estateDuty: number;
  cashDeficit: number;
  residueState: ResiduePageState;
  setResidueState: React.Dispatch<React.SetStateAction<ResiduePageState>>;
}

const RemainsPage: React.FC<RemainsPageProps> = ({
  clientName,
  netAssetsAvailable,
  estateDuty,
  cashDeficit,
  residueState,
  setResidueState
}) => {
  const formatCurrency = (num: number) => {
    return num.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 });
  };

  const handleSpouseLegacyChange = (val: string) => {
    const numericVal = val.replace(/[^0-9.]/g, '');
    const parsed = numericVal === '' ? 0 : parseFloat(numericVal);
    setResidueState(prev => ({ ...prev, spouseLegacy: parsed }));
  };

  const addLegacy = () => {
    const newLegacy: Legacy = { id: crypto.randomUUID(), description: '', value: 0 };
    setResidueState(prev => ({ ...prev, thirdPartyLegacies: [...prev.thirdPartyLegacies, newLegacy] }));
  };

  const removeLegacy = (id: string) => {
    setResidueState(prev => ({ ...prev, thirdPartyLegacies: prev.thirdPartyLegacies.filter(l => l.id !== id) }));
  };

  const updateLegacy = (id: string, field: keyof Legacy, val: string) => {
    setResidueState(prev => ({
      ...prev,
      thirdPartyLegacies: prev.thirdPartyLegacies.map(l => {
        if (l.id !== id) return l;
        if (field === 'description') return { ...l, description: val };
        const numericVal = val.replace(/[^0-9.]/g, '');
        return { ...l, value: numericVal === '' ? 0 : parseFloat(numericVal) };
      })
    }));
  };

  const totalThirdPartyLegacies = residueState.thirdPartyLegacies.reduce((sum, l) => sum + (l.value || 0), 0);
  const totalDeductions = residueState.spouseLegacy + totalThirdPartyLegacies;
  const residueForSec4q = Math.max(0, netAssetsAvailable - totalDeductions);
  const actualResidueValue = residueForSec4q - estateDuty - cashDeficit;

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-32">
      <div className="bg-slate-800 rounded-xl p-6 shadow-lg border-b-4 border-slate-600 text-white flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-black uppercase tracking-tight">Residue Calculation</h2>
          <p className="text-slate-400 text-xs font-medium uppercase tracking-widest mt-1">Final Distribution Analysis</p>
        </div>
        <div className="text-right">
          <span className="text-slate-400 font-bold uppercase text-[10px] block tracking-widest mb-1">Estate</span>
          <span className="text-xl font-black uppercase border-b-2 border-slate-500/30 pb-1">{clientName || 'Unknown'}</span>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="bg-indigo-700 p-5 flex justify-between items-center text-white">
          <h3 className="font-black uppercase tracking-widest text-xs flex items-center gap-2">
            <LinkIcon size={14} className="text-indigo-300" /> Net Assets and Policies
          </h3>
          <div className="text-xl font-mono font-black">R {formatCurrency(netAssetsAvailable)}</div>
        </div>

        <div className="p-8 space-y-8">
          <div className="flex flex-col sm:flex-row justify-between items-center p-6 bg-rose-50/50 rounded-2xl border border-rose-100">
            <div className="flex items-center gap-4 mb-4 sm:mb-0">
              <div className="p-3 bg-rose-500 rounded-xl text-white shadow-lg shadow-rose-200">
                <Heart size={24} fill="currentColor" />
              </div>
              <div>
                <span className="text-rose-900 font-black uppercase text-xs tracking-tight block">Bequests to Spouse (Sec 4(q))</span>
                <span className="text-rose-400 text-[10px] font-bold uppercase tracking-widest">Specific Spouse Bequests</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-rose-300 font-mono text-sm">R</span>
              <input
                type="text"
                inputMode="numeric"
                value={residueState.spouseLegacy === 0 ? '' : residueState.spouseLegacy.toString()}
                onChange={(e) => handleSpouseLegacyChange(e.target.value)}
                placeholder="0"
                className="bg-white border border-rose-200 rounded-xl px-4 py-3 text-right w-48 font-mono font-black text-rose-800 shadow-sm focus:ring-2 focus:ring-rose-500/20 outline-none"
              />
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between px-2">
              <h4 className="text-slate-500 font-black uppercase text-[10px] tracking-[0.2em] flex items-center gap-2">
                <User size={14} /> Bequests to Third Parties
              </h4>
              <button 
                onClick={addLegacy}
                className="flex items-center gap-1 text-emerald-600 text-[10px] font-black uppercase tracking-widest hover:text-emerald-700 transition-colors"
              >
                <Plus size={14} className="stroke-[3]" /> Add Bequest
              </button>
            </div>

            <div className="bg-slate-50/50 rounded-2xl border border-slate-100 divide-y divide-slate-100 overflow-hidden">
              {residueState.thirdPartyLegacies.map((legacy, idx) => (
                <div key={legacy.id} className="group flex flex-col sm:flex-row items-center gap-4 p-4 hover:bg-white transition-colors">
                  <span className="text-slate-300 font-black text-xs">{idx + 1}.</span>
                  <input
                    type="text"
                    value={legacy.description}
                    onChange={(e) => updateLegacy(legacy.id, 'description', e.target.value)}
                    placeholder="Legacy description..."
                    className="flex-1 bg-transparent border-none focus:ring-0 font-bold text-slate-700 placeholder:text-slate-200 text-sm uppercase"
                  />
                  <div className="flex items-center gap-2">
                    <span className="text-slate-300 font-mono text-sm">R</span>
                    <input
                      type="text"
                      inputMode="numeric"
                      value={legacy.value === 0 ? '' : legacy.value.toString()}
                      onChange={(e) => updateLegacy(legacy.id, 'value', e.target.value)}
                      placeholder="0"
                      className="bg-white border border-slate-200 rounded-lg px-3 py-1.5 text-right w-36 font-mono font-bold text-slate-800 shadow-sm focus:ring-2 focus:ring-emerald-500/20 outline-none"
                    />
                    <button 
                      onClick={() => removeLegacy(legacy.id)}
                      className="p-1 text-slate-200 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              ))}
              {residueState.thirdPartyLegacies.length === 0 && (
                <div className="p-8 text-center text-slate-300 text-xs font-bold uppercase tracking-widest italic">
                  No third party bequests entered
                </div>
              )}
            </div>
          </div>

          <div className="flex flex-col items-end pt-4 space-y-4">
             <div className="flex justify-between items-center w-full max-w-sm px-6 py-3 bg-slate-100 rounded-xl text-slate-600">
                <span className="text-[10px] font-black uppercase tracking-widest">Total Deductions</span>
                <span className="font-mono font-black">R {formatCurrency(totalDeductions)}</span>
             </div>

             <div className="flex justify-between items-center w-full max-w-sm px-6 py-4 bg-slate-900 rounded-xl text-emerald-400 border-l-4 border-emerald-500">
                <span className="text-[10px] font-black uppercase tracking-widest">Residue for Sec 4(q) purposes</span>
                <span className="text-xl font-mono font-black">R {formatCurrency(residueForSec4q)}</span>
             </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-indigo-50/50 rounded-2xl border border-indigo-100 p-8 flex justify-between items-center shadow-sm">
           <div className="flex items-center gap-4">
              <div className="p-3 bg-indigo-100 rounded-xl text-indigo-600">
                <Calculator size={24} />
              </div>
              <div>
                <span className="text-indigo-900 font-black uppercase text-[10px] tracking-tight block">Estate Duty Payable</span>
                <span className="text-indigo-600 font-black text-[8px] uppercase tracking-widest flex items-center gap-1 mt-1">
                   <LinkIcon size={10}/> Synced Tax
                </span>
              </div>
           </div>
           <div className="text-2xl font-mono font-black text-indigo-700">R {formatCurrency(estateDuty)}</div>
        </div>

        <div className="bg-indigo-50/50 rounded-2xl border border-indigo-100 p-8 flex justify-between items-center shadow-sm">
           <div className="flex items-center gap-4">
              <div className="p-3 bg-indigo-100 rounded-xl text-indigo-600">
                <AlertCircle size={24} />
              </div>
              <div>
                <span className="text-indigo-900 font-black uppercase text-[10px] tracking-tight block">Cash Deficit</span>
                <span className="text-indigo-600 font-black text-[8px] uppercase tracking-widest flex items-center gap-1 mt-1">
                   <LinkIcon size={10}/> Synced Deficit
                </span>
              </div>
           </div>
           <div className="text-2xl font-mono font-black text-indigo-700">R {formatCurrency(cashDeficit)}</div>
        </div>
      </div>

      <div className="bg-emerald-700 rounded-2xl p-10 flex flex-col md:flex-row justify-between items-center shadow-2xl border-b-8 border-emerald-900 text-white overflow-hidden relative">
        <div className="absolute top-0 right-0 p-4 opacity-10">
           <CheckCircle size={120} />
        </div>
        <div className="relative z-10 flex items-center gap-6 mb-8 md:mb-0">
          <div className="p-4 bg-white/20 rounded-2xl">
            <ArrowDown className="w-10 h-10 text-white" />
          </div>
          <div>
            <h3 className="text-3xl font-black uppercase tracking-tighter leading-tight">Actual Residue</h3>
            <p className="text-emerald-100 text-xs font-bold uppercase tracking-widest mt-1">Final Residue after Deficit Allocation</p>
          </div>
        </div>
        <div className="relative z-10 text-center md:text-right">
          <div className="text-6xl font-mono font-black drop-shadow-lg">
            R {formatCurrency(actualResidueValue)}
          </div>
          <p className="text-emerald-200 text-[10px] font-black uppercase tracking-[0.3em] mt-2">Available for Residuary Heirs</p>
        </div>
      </div>
    </div>
  );
};

export default RemainsPage;

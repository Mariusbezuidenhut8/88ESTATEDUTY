
import React, { useState, useEffect } from 'react';
import { ShieldCheck, Lock, AlertCircle, Loader2, ChevronRight } from 'lucide-react';
import { AccessRole, PermissionCode, AccessSession } from '../types';

interface AccessScreenProps {
  onGrantAccess: (session: AccessSession) => void;
}

const AccessScreen: React.FC<AccessScreenProps> = ({ onGrantAccess }) => {
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [attempts, setAttempts] = useState(0);
  const [cooldown, setCooldown] = useState(0);

  useEffect(() => {
    if (cooldown > 0) {
      const timer = setInterval(() => setCooldown((c) => c - 1), 1000);
      return () => clearInterval(timer);
    }
  }, [cooldown]);

  const validateCode = async () => {
    if (cooldown > 0) return;
    setLoading(true);
    setError(null);

    // Simulate Server-side verification
    await new Promise((resolve) => setTimeout(resolve, 800));

    const storedCodes: PermissionCode[] = JSON.parse(localStorage.getItem('88WM_CODES') || '[]');
    
    // Default Admin Code for initial testing if no codes exist
    if (storedCodes.length === 0 && code === '88WM-ADMIN-2025') {
       onGrantAccess({
          token: crypto.randomUUID(),
          role: 'ADMIN',
          expiresAt: Date.now() + 24 * 60 * 60 * 1000
       });
       return;
    }

    const matched = storedCodes.find((c) => c.code.toUpperCase() === code.toUpperCase() && c.isActive);

    if (matched) {
      const now = new Date();
      if (matched.expiresAt && new Date(matched.expiresAt) < now) {
        setError('THIS ACCESS CODE HAS EXPIRED');
      } else if (matched.currentUses >= matched.maxUses) {
        setError('MAXIMUM USAGE REACHED FOR THIS CODE');
      } else {
        // Increment usage count in "DB"
        matched.currentUses += 1;
        localStorage.setItem('88WM_CODES', JSON.stringify(storedCodes));
        
        onGrantAccess({
          token: crypto.randomUUID(),
          role: matched.role,
          expiresAt: Date.now() + 24 * 60 * 60 * 1000
        });
        return;
      }
    } else {
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);
      setError('INVALID PERMISSION CODE');
      if (newAttempts >= 3) {
        setCooldown(30 * (newAttempts - 2)); // 30s, 60s, etc.
      }
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-6 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-80 h-80 bg-emerald-500 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-80 h-80 bg-indigo-500 rounded-full blur-[120px] animate-pulse" />
      </div>

      <div className="w-full max-w-lg relative z-10">
        <div className="flex flex-col items-center text-center mb-12">
          <div className="flex items-center gap-10 mb-8 p-8 bg-slate-900/40 rounded-[2.5rem] border border-slate-800">
            <div className="flex flex-col items-start">
              <span className="text-5xl font-black tracking-tighter text-white">88 WEALTH</span>
              <span className="text-sm font-bold tracking-[0.4em] text-slate-500 uppercase mt-1">MANAGEMENT</span>
            </div>
            
            <div className="flex items-center gap-6">
              <div className="w-px h-16 bg-slate-800" />
              <p className="text-[11px] font-medium leading-snug text-slate-500 italic text-left">
                operating under the FSP license<br/>
                number 9328 of Fairbairn Consult<br/>
                (Pty) Ltd
              </p>
            </div>
          </div>
          
          <h1 className="text-xl font-black text-white uppercase tracking-[0.4em] mb-2">Secure Access</h1>
          <p className="text-slate-500 text-xs font-bold uppercase tracking-widest leading-relaxed">
            Professional Calculation Suite • Restricted Access
          </p>
        </div>

        <div className="bg-slate-900/50 backdrop-blur-xl border border-slate-800 rounded-3xl p-8 shadow-2xl">
          <div className="space-y-6">
            <div>
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest block mb-3 ml-1">
                Enter Permission Code
              </label>
              <div className="relative group">
                <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-emerald-500 transition-colors">
                  <Lock size={18} />
                </div>
                <input
                  type="text"
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                  onKeyDown={(e) => e.key === 'Enter' && validateCode()}
                  placeholder="XXXX-XXXX-XXXX"
                  disabled={loading || cooldown > 0}
                  className="w-full bg-slate-950/50 border-2 border-slate-800 rounded-2xl py-4 pl-12 pr-4 text-white font-mono font-black tracking-[0.2em] focus:outline-none focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 transition-all placeholder:text-slate-800"
                />
              </div>
            </div>

            {error && (
              <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 flex items-center gap-3 text-red-500">
                <AlertCircle size={18} className="shrink-0" />
                <span className="text-[10px] font-black uppercase tracking-widest">{error}</span>
              </div>
            )}

            {cooldown > 0 && (
              <div className="bg-orange-500/10 border border-orange-500/20 rounded-xl p-4 flex items-center gap-3 text-orange-500">
                <Loader2 size={18} className="shrink-0 animate-spin" />
                <span className="text-[10px] font-black uppercase tracking-widest">Brute Force Protection Active: Wait {cooldown}s</span>
              </div>
            )}

            <button
              onClick={validateCode}
              disabled={loading || !code || cooldown > 0}
              className="w-full bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 disabled:text-slate-600 text-slate-950 font-black uppercase tracking-[0.2em] py-4 rounded-2xl transition-all shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 group"
            >
              {loading ? (
                <Loader2 className="animate-spin" size={20} />
              ) : (
                <>
                  Authenticate <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </button>
          </div>
        </div>

        <div className="mt-8 text-center flex items-center justify-center gap-2">
           <ShieldCheck size={14} className="text-emerald-500" />
           <span className="text-[9px] font-black text-slate-600 uppercase tracking-widest">Encrypted via RSA-4096 Protocol</span>
        </div>
      </div>
    </div>
  );
};

export default AccessScreen;

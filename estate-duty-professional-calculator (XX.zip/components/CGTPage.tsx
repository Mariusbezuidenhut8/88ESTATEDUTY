
import React, { useState } from 'react';
import { 
  CGTState, CGTAsset, Farm, BusinessInterestsState, 
  ResidentialState, InvestmentState 
} from '../types';
import { Plus, Trash2, Calculator, Lock, Percent, ArrowRight, ShieldCheck, Landmark, Home, Briefcase, TrendingUp, Link as LinkIcon, Info, X, Clock, Zap } from 'lucide-react';

interface CGTPageProps {
  clientName: string;
  cgt: CGTState;
  setCgt: React.Dispatch<React.SetStateAction<CGTState>>;
  farms: Farm[];
  setFarms: React.Dispatch<React.SetStateAction<Farm[]>>;
  business: BusinessInterestsState;
  setBusiness: React.Dispatch<React.SetStateAction<BusinessInterestsState>>;
  residential: ResidentialState;
  setResidential: React.Dispatch<React.SetStateAction<ResidentialState>>;
  investments: InvestmentState;
  setInvestments: React.Dispatch<React.SetStateAction<InvestmentState>>;
}

const CGTPage: React.FC<CGTPageProps> = ({ 
  clientName, cgt, setCgt, farms, setFarms, 
  business, setBusiness, residential, setResidential, investments, setInvestments 
}) => {
  const [showExclusionTooltip, setShowExclusionTooltip] = useState(false);
  const [showRule20Tooltip, setShowRule20Tooltip] = useState(false);

  const formatCurrency = (num: number) => {
    return num.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 });
  };

  const handleGlobalNumericChange = (field: keyof CGTState, val: string) => {
    const numericVal = val.replace(/[^0-9.]/g, '');
    const parsed = numericVal === '' ? 0 : parseFloat(numericVal);
    setCgt(prev => ({ ...prev, [field]: parsed }));
  };

  const handleRule20Change = (subField: string, val: string) => {
    const numericVal = val.replace(/[^0-9.]/g, '');
    const parsed = numericVal === '' ? 0 : parseFloat(numericVal);
    setCgt(prev => ({ ...prev, rule20: { ...prev.rule20, [subField]: parsed } }));
  };

  // Helper for SARS 20% Base Cost Rule
  const getEffectiveGain = (proceeds: number, baseCost: number, exclusion: number = 0) => {
    const effectiveBase = baseCost > 0 ? baseCost : (proceeds * 0.2);
    return Math.max(0, proceeds - effectiveBase - exclusion);
  };

  // --- SYNCED ASSET UPDATERS ---
  const updateFarmBase = (id: string, val: string) => {
    const numericVal = val.replace(/[^0-9.]/g, '');
    const parsed = numericVal === '' ? 0 : parseFloat(numericVal);
    setFarms(prev => prev.map(f => f.id === id ? { ...f, baseCost: parsed } : f));
  };

  const updateResidentialBase = (field: 'property1Base' | 'property2Base' | 'holidayHomeBase', val: string) => {
    const numericVal = val.replace(/[^0-9.]/g, '');
    const parsed = numericVal === '' ? 0 : parseFloat(numericVal);
    setResidential(prev => ({ ...prev, [field]: parsed }));
  };

  const updateBusinessBase = (field: 'soleProprietorshipBase' | 'partnershipBase' | 'ccInterestBase' | 'companySharesBase', val: string) => {
    const numericVal = val.replace(/[^0-9.]/g, '');
    const parsed = numericVal === '' ? 0 : parseFloat(numericVal);
    setBusiness(prev => ({ ...prev, [field]: parsed }));
  };

  const updateInvestmentBase = (field: 'sharesBase' | 'unitTrustsBase', val: string) => {
    const numericVal = val.replace(/[^0-9.]/g, '');
    const parsed = numericVal === '' ? 0 : parseFloat(numericVal);
    setInvestments(prev => ({ ...prev, [field]: parsed }));
  };

  // --- MANUAL ASSET UPDATERS ---
  const addManualAsset = () => {
    const newAsset: CGTAsset = { id: crypto.randomUUID(), description: '', marketValue: 0, baseCost: 0 };
    setCgt(prev => ({ ...prev, otherAssets: [...prev.otherAssets, newAsset] }));
  };

  const updateManualAsset = (id: string, field: keyof CGTAsset, val: string) => {
    setCgt(prev => ({
      ...prev,
      otherAssets: prev.otherAssets.map(a => {
        if (a.id !== id) return a;
        if (field === 'description') return { ...a, [field]: val };
        const numericVal = val.replace(/[^0-9.]/g, '');
        return { ...a, [field]: numericVal === '' ? 0 : parseFloat(numericVal) };
      })
    }));
  };

  const removeManualAsset = (id: string) => {
    setCgt(prev => ({ ...prev, otherAssets: prev.otherAssets.filter(a => a.id !== id) }));
  };

  // --- CALCULATIONS ---
  const farmGains = farms.reduce((sum, f) => sum + getEffectiveGain(f.marketValue, f.baseCost), 0);
  const residentialGains = 
    getEffectiveGain(residential.property1, residential.property1Base, cgt.primaryResidenceExclusion) +
    getEffectiveGain(residential.property2, residential.property2Base) +
    getEffectiveGain(residential.holidayHome, residential.holidayHomeBase);
  const businessGains = 
    getEffectiveGain(business.soleProprietorship, business.soleProprietorshipBase) +
    getEffectiveGain(business.partnership, business.partnershipBase) +
    getEffectiveGain(business.ccInterest, business.ccInterestBase) +
    getEffectiveGain(business.companyShares, business.companySharesBase);
  const investmentGains = 
    getEffectiveGain(investments.shares, investments.sharesBase) +
    getEffectiveGain(investments.unitTrusts, investments.unitTrustsBase);
  const manualGains = cgt.otherAssets.reduce((sum, a) => sum + getEffectiveGain(a.marketValue, a.baseCost), 0);

  const totalGrossGain = farmGains + residentialGains + businessGains + investmentGains + manualGains;
  const netCapitalGain = Math.max(0, totalGrossGain - cgt.annualExclusion - cgt.rollOverExemption);
  const standardCGT = netCapitalGain * (cgt.inclusionRate / 100) * (cgt.taxRate / 100);

  const rule20BaseCost = (cgt.rule20.marketValueLessImprovements || 0) * 0.20;
  const rule20Gain = Math.max(0, (cgt.rule20.marketValueLessImprovements || 0) - rule20BaseCost - (cgt.rule20.discount || 0));
  const rule20CGT = rule20Gain * (cgt.rule20.inclusionRate / 100) * (cgt.rule20.taxRate / 100);

  const totalLiability = standardCGT + rule20CGT;

  const SectionHeader = ({ icon: Icon, title, color }: { icon: any, title: string, color: string }) => (
    <div className={`${color} p-4 flex justify-between items-center text-white rounded-t-xl`}>
      <h3 className="font-black uppercase tracking-widest text-xs flex items-center gap-3">
        <Icon size={18} /> {title}
      </h3>
      <span className="text-[10px] font-black uppercase tracking-widest bg-white/20 px-2 py-0.5 rounded flex items-center gap-1">
        <LinkIcon size={10} /> Synced Assets
      </span>
    </div>
  );

  const Rule20Badge = () => (
    <div className="flex items-center gap-1 bg-amber-100 text-amber-700 text-[8px] font-black px-1.5 py-0.5 rounded-full uppercase tracking-widest animate-pulse border border-amber-200">
      <Zap size={8} /> SARS 20% RULE
    </div>
  );

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-32">
      <div className="bg-slate-800 rounded-xl p-6 shadow-lg border-b-4 border-slate-600 text-white flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-black uppercase tracking-tight">CGT Summary Analysis</h2>
          <p className="text-slate-400 text-xs font-medium uppercase tracking-widest mt-1">Synced Proceeds & Base Cost Determinations</p>
        </div>
        <div className="text-right">
          <span className="text-slate-400 font-bold uppercase text-[10px] block tracking-widest mb-1">Estate</span>
          <span className="text-xl font-black uppercase border-b-2 border-slate-500/30 pb-1">{clientName || 'Unknown'}</span>
        </div>
      </div>

      <div className="space-y-8">
        {/* AGRICULTURAL SECTION */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <SectionHeader icon={Landmark} title="Agricultural Property (at 100% for CGT)" color="bg-emerald-700" />
          <div className="p-0">
            <table className="w-full border-collapse text-left">
              <thead className="bg-slate-50 text-[9px] font-black uppercase tracking-widest text-slate-400 border-b border-slate-100">
                <tr>
                  <th className="px-6 py-3 w-1/3">Farm Description</th>
                  <th className="px-6 py-3 text-right">Proceeds (100%)</th>
                  <th className="px-6 py-3 text-right">Base Cost</th>
                  <th className="px-6 py-3 text-right text-emerald-600">Gross Gain</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {farms.map(farm => (
                  <tr key={farm.id} className="group hover:bg-slate-50/50">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                         <ShieldCheck size={14} className="text-emerald-500" />
                         <span className="font-bold text-slate-700 text-sm">{farm.name || 'Unnamed Farm'}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right font-mono font-black text-indigo-700 bg-indigo-50/20 border-x border-indigo-50">R {formatCurrency(farm.marketValue)}</td>
                    <td className="px-6 py-4">
                       <div className="flex flex-col items-end gap-1">
                          <div className="flex items-center justify-end gap-1">
                             <span className="text-slate-300 font-mono text-xs">R</span>
                             <input type="text" value={farm.baseCost === 0 ? '' : farm.baseCost.toString()} onChange={(e) => updateFarmBase(farm.id, e.target.value)} className="w-32 bg-white border border-slate-200 rounded px-2 py-1 text-right font-mono font-black text-slate-800 focus:outline-none focus:border-emerald-500" />
                          </div>
                          {farm.baseCost === 0 && <Rule20Badge />}
                       </div>
                    </td>
                    <td className="px-6 py-4 text-right font-mono font-black text-emerald-600">R {formatCurrency(getEffectiveGain(farm.marketValue, farm.baseCost))}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* RESIDENTIAL SECTION */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <SectionHeader icon={Home} title="Residential Property" color="bg-blue-700" />
          <div className="p-0">
            <table className="w-full border-collapse text-left">
              <thead className="bg-slate-50 text-[9px] font-black uppercase tracking-widest text-slate-400 border-b border-slate-100">
                <tr>
                  <th className="px-6 py-3 w-1/3">Property Name</th>
                  <th className="px-6 py-3 text-right">Proceeds (100%)</th>
                  <th className="px-6 py-3 text-right">Base Cost</th>
                  <th className="px-6 py-3 text-right text-blue-600">Gross Gain</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {/* Prop 1 */}
                <tr className="group hover:bg-slate-50/50">
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                       <span className="font-black text-slate-700 text-sm uppercase tracking-tight">{residential.property1Name || 'Primary Residence'}</span>
                       <span className="text-[9px] font-bold text-blue-500 uppercase tracking-widest">Applying R{formatCurrency(cgt.primaryResidenceExclusion / 1000000)}m Exclusion</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right font-mono font-black text-indigo-700 bg-indigo-50/20 border-x border-indigo-50">R {formatCurrency(residential.property1)}</td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex flex-col items-end gap-1">
                      <div className="flex items-center justify-end gap-1">
                          <span className="text-slate-300 font-mono text-xs">R</span>
                          <input type="text" value={residential.property1Base === 0 ? '' : residential.property1Base.toString()} onChange={(e) => updateResidentialBase('property1Base', e.target.value)} className="w-32 bg-white border border-slate-200 rounded px-2 py-1 text-right font-mono font-black text-slate-800" />
                      </div>
                      {residential.property1Base === 0 && <Rule20Badge />}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right font-mono font-black text-blue-600">R {formatCurrency(getEffectiveGain(residential.property1, residential.property1Base, cgt.primaryResidenceExclusion))}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* BUSINESS INTERESTS SECTION */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <SectionHeader icon={Briefcase} title="Business Interests" color="bg-slate-700" />
          <div className="p-0">
            <table className="w-full border-collapse text-left">
              <thead className="bg-slate-50 text-[9px] font-black uppercase tracking-widest text-slate-400 border-b border-slate-100">
                <tr>
                  <th className="px-6 py-3 w-1/3">Interest Type</th>
                  <th className="px-6 py-3 text-right">Proceeds</th>
                  <th className="px-6 py-3 text-right">Base Cost</th>
                  <th className="px-6 py-3 text-right text-slate-900">Gross Gain</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {[
                  { label: "Sole Proprietorship", proceeds: business.soleProprietorship, base: business.soleProprietorshipBase, field: "soleProprietorshipBase" },
                  { label: "Partnership", proceeds: business.partnership, base: business.partnershipBase, field: "partnershipBase" },
                  { label: "CC Interest", proceeds: business.ccInterest, base: business.ccInterestBase, field: "ccInterestBase" },
                  { label: "Company Shares", proceeds: business.companyShares, base: business.companySharesBase, field: "companySharesBase" }
                ].filter(b => b.proceeds > 0).map((b, idx) => (
                  <tr key={idx} className="group hover:bg-slate-50/50">
                    <td className="px-6 py-4 font-black text-slate-700 text-xs uppercase tracking-tight">{b.label}</td>
                    <td className="px-6 py-4 text-right font-mono font-black text-indigo-700 bg-indigo-50/20 border-x border-indigo-50">R {formatCurrency(b.proceeds)}</td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex flex-col items-end gap-1">
                        <div className="flex items-center justify-end gap-1">
                            <span className="text-slate-300 font-mono text-xs">R</span>
                            <input type="text" value={b.base === 0 ? '' : b.base.toString()} onChange={(e) => updateBusinessBase(b.field as any, e.target.value)} className="w-32 bg-white border border-slate-200 rounded px-2 py-1 text-right font-mono font-black text-slate-800" />
                        </div>
                        {b.base === 0 && <Rule20Badge />}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right font-mono font-black text-slate-900">R {formatCurrency(getEffectiveGain(b.proceeds, b.base))}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* INVESTMENTS SECTION */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <SectionHeader icon={TrendingUp} title="Investments & Equity" color="bg-indigo-700" />
          <div className="p-0">
            <table className="w-full border-collapse text-left">
              <thead className="bg-slate-50 text-[9px] font-black uppercase tracking-widest text-slate-400 border-b border-slate-100">
                <tr>
                  <th className="px-6 py-3 w-1/3">Investment Type</th>
                  <th className="px-6 py-3 text-right">Proceeds</th>
                  <th className="px-6 py-3 text-right">Base Cost</th>
                  <th className="px-6 py-3 text-right text-indigo-600">Gross Gain</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {[
                  { label: "Listed Shares", proceeds: investments.shares, base: investments.sharesBase, field: "sharesBase" },
                  { label: "Unit Trusts", proceeds: investments.unitTrusts, base: investments.unitTrustsBase, field: "unitTrustsBase" }
                ].filter(i => i.proceeds > 0).map((i, idx) => (
                  <tr key={idx} className="group hover:bg-slate-50/50">
                    <td className="px-6 py-4 font-black text-slate-700 text-xs uppercase tracking-tight">{i.label}</td>
                    <td className="px-6 py-4 text-right font-mono font-black text-indigo-700 bg-indigo-50/20 border-x border-indigo-50">R {formatCurrency(i.proceeds)}</td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex flex-col items-end gap-1">
                        <div className="flex items-center justify-end gap-1">
                            <span className="text-slate-300 font-mono text-xs">R</span>
                            <input type="text" value={i.base === 0 ? '' : i.base.toString()} onChange={(e) => updateInvestmentBase(i.field as any, e.target.value)} className="w-32 bg-white border border-slate-200 rounded px-2 py-1 text-right font-mono font-black text-slate-800" />
                        </div>
                        {i.base === 0 && <Rule20Badge />}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right font-mono font-black text-indigo-600">R {formatCurrency(getEffectiveGain(i.proceeds, i.base))}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* MANUAL ASSETS SECTION */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="bg-slate-500 p-4 flex justify-between items-center text-white">
            <h3 className="font-black uppercase tracking-widest text-xs flex items-center gap-3">
              <Calculator size={18} /> Additional (Manual) Assets
            </h3>
            <button onClick={addManualAsset} className="bg-white/20 hover:bg-white/30 text-[9px] font-black uppercase tracking-widest px-3 py-1 rounded transition-colors flex items-center gap-1">
               <Plus size={12}/> Add Asset
            </button>
          </div>
          <div className="p-0">
            <table className="w-full border-collapse text-left">
              <thead className="bg-slate-50 text-[9px] font-black uppercase tracking-widest text-slate-400 border-b border-slate-100">
                <tr>
                  <th className="px-6 py-3 w-1/3">Description</th>
                  <th className="px-6 py-3 text-right">Proceeds</th>
                  <th className="px-6 py-3 text-right">Base Cost</th>
                  <th className="px-6 py-3 text-right">Gross Gain</th>
                  <th className="w-12"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {cgt.otherAssets.map(asset => (
                  <tr key={asset.id} className="group hover:bg-slate-50/50">
                    <td className="px-6 py-4">
                       <input type="text" value={asset.description} onChange={(e) => updateManualAsset(asset.id, 'description', e.target.value)} className="w-full bg-transparent border-none focus:ring-0 font-bold text-slate-700 uppercase text-xs" placeholder="Asset Description..." />
                    </td>
                    <td className="px-6 py-4 text-right">
                       <div className="flex items-center justify-end gap-1">
                          <span className="text-slate-300 font-mono text-xs">R</span>
                          <input type="text" value={asset.marketValue === 0 ? '' : asset.marketValue.toString()} onChange={(e) => updateManualAsset(asset.id, 'marketValue', e.target.value)} className="w-24 bg-transparent text-right font-mono font-bold text-slate-800 border-b border-slate-100 focus:border-slate-400 focus:outline-none" />
                       </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                       <div className="flex flex-col items-end gap-1">
                          <div className="flex items-center justify-end gap-1">
                             <span className="text-slate-300 font-mono text-xs">R</span>
                             <input type="text" value={asset.baseCost === 0 ? '' : asset.baseCost.toString()} onChange={(e) => updateManualAsset(asset.id, 'baseCost', e.target.value)} className="w-24 bg-transparent text-right font-mono font-bold text-slate-800 border-b border-slate-100 focus:border-slate-400 focus:outline-none" />
                          </div>
                          {asset.baseCost === 0 && <Rule20Badge />}
                       </div>
                    </td>
                    <td className="px-6 py-4 text-right font-mono font-black text-slate-900">R {formatCurrency(getEffectiveGain(asset.marketValue, asset.baseCost))}</td>
                    <td className="px-4 py-4 text-center">
                       <button onClick={() => removeManualAsset(asset.id)} className="text-slate-200 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100">
                          <Trash2 size={14} />
                       </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* CGT REBATES & FINAL CALCULATION */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 pt-6 relative">
           <div className="bg-slate-100 rounded-2xl p-6 space-y-4 border border-slate-200 relative">
              <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-2">Exemptions & Rates</h4>
              
              <div className="flex justify-between items-center py-2 border-b border-slate-200 relative">
                 <div className="flex items-center gap-2">
                   <span className="text-xs font-bold text-slate-600 uppercase tracking-tight">Primary Residence Exclusion</span>
                   <button 
                     onClick={() => setShowExclusionTooltip(!showExclusionTooltip)}
                     className={`p-1 rounded-full transition-colors ${showExclusionTooltip ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-blue-600 hover:bg-blue-50'}`}
                   >
                     <Info size={14} />
                   </button>
                 </div>

                 {/* Tooltip Popover */}
                 {showExclusionTooltip && (
                   <div className="absolute bottom-full left-0 mb-4 z-[50] w-72 p-4 bg-slate-900 text-white rounded-2xl shadow-2xl border border-slate-700 animate-in fade-in slide-in-from-bottom-2 duration-200">
                     <div className="flex justify-between items-start mb-2">
                       <h5 className="text-[10px] font-black uppercase tracking-widest text-blue-400">Statutory Guidance</h5>
                       <button onClick={() => setShowExclusionTooltip(false)} className="text-slate-500 hover:text-white">
                         <X size={12} />
                       </button>
                     </div>
                     <p className="text-[11px] leading-relaxed font-medium text-slate-300 italic">
                       The first <span className="text-white font-bold">R2 million</span> of a capital gain or loss on the disposal of a primary residence by a natural person or special trust is excluded from CGT. 
                     </p>
                     <p className="text-[11px] leading-relaxed font-medium text-slate-300 mt-2">
                       This applies only if the property is used as the main residence for the period of ownership and is owned in a personal capacity.
                     </p>
                     <div className="absolute top-full left-6 w-3 h-3 bg-slate-900 rotate-45 -mt-1.5 border-b border-r border-slate-700"></div>
                   </div>
                 )}

                 <div className="flex items-center gap-2">
                    <span className="text-slate-400 font-mono text-xs">R</span>
                    <input type="text" value={cgt.primaryResidenceExclusion.toString()} onChange={(e) => handleGlobalNumericChange('primaryResidenceExclusion', e.target.value)} className="w-24 bg-white border border-slate-300 rounded px-2 py-1 text-right font-mono font-black text-slate-800" />
                 </div>
              </div>

              <div className="flex justify-between items-center py-2 border-b border-slate-200">
                 <span className="text-xs font-bold text-slate-600 uppercase tracking-tight">Annual Exclusion</span>
                 <div className="flex items-center gap-2">
                    <span className="text-slate-400 font-mono text-xs">R</span>
                    <input type="text" value={cgt.annualExclusion.toString()} onChange={(e) => handleGlobalNumericChange('annualExclusion', e.target.value)} className="w-24 bg-white border border-slate-300 rounded px-2 py-1 text-right font-mono font-black text-slate-800" />
                 </div>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-slate-200">
                 <span className="text-xs font-bold text-slate-600 uppercase tracking-tight">Inclusion Rate</span>
                 <div className="flex items-center gap-2">
                    <input type="text" value={cgt.inclusionRate.toString()} onChange={(e) => handleGlobalNumericChange('inclusionRate', e.target.value)} className="w-16 bg-white border border-slate-300 rounded px-2 py-1 text-center font-mono font-black text-slate-800" />
                    <span className="text-slate-400 font-black text-xs">%</span>
                 </div>
              </div>
              <div className="flex justify-between items-center py-2">
                 <span className="text-xs font-bold text-slate-600 uppercase tracking-tight">Effective Tax Rate</span>
                 <div className="flex items-center gap-2">
                    <input type="text" value={cgt.taxRate.toString()} onChange={(e) => handleGlobalNumericChange('taxRate', e.target.value)} className="w-16 bg-white border border-slate-300 rounded px-2 py-1 text-center font-mono font-black text-slate-800" />
                    <span className="text-slate-400 font-black text-xs">%</span>
                 </div>
              </div>

              {/* RULE 20 SUBSECTION */}
              <div className="mt-8 pt-6 border-t border-slate-200 space-y-4">
                 <div className="flex items-center justify-between">
                    <h5 className="text-[10px] font-black uppercase tracking-widest text-indigo-600 flex items-center gap-2">
                       <Clock size={12}/> Rule 20 (Pre-2001 Assets)
                    </h5>
                    <button 
                      onClick={() => setShowRule20Tooltip(!showRule20Tooltip)}
                      className="text-slate-400 hover:text-indigo-600 transition-colors"
                    >
                      <Info size={14} />
                    </button>
                 </div>

                 {showRule20Tooltip && (
                   <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-4 text-[10px] font-medium text-indigo-900 leading-relaxed mb-4">
                      Used for assets acquired before 1 October 2001. Calculation assumes 20% of the proceeds (less improvements) as the Base Cost if no other records exist.
                   </div>
                 )}

                 <div className="flex justify-between items-center py-2 border-b border-indigo-50">
                    <span className="text-[10px] font-bold text-slate-600 uppercase tracking-tight">Proceeds less Improvements</span>
                    <div className="flex items-center gap-2">
                       <span className="text-slate-300 font-mono text-xs">R</span>
                       <input type="text" value={cgt.rule20.marketValueLessImprovements.toString()} onChange={(e) => handleRule20Change('marketValueLessImprovements', e.target.value)} className="w-24 bg-white border border-slate-300 rounded px-2 py-1 text-right font-mono font-black text-slate-800" />
                    </div>
                 </div>

                 <div className="flex justify-between items-center py-2 border-b border-indigo-50">
                    <span className="text-[10px] font-bold text-slate-600 uppercase tracking-tight">Rule 20 Tax Rate</span>
                    <div className="flex items-center gap-2">
                       <input type="text" value={cgt.rule20.taxRate.toString()} onChange={(e) => handleRule20Change('taxRate', e.target.value)} className="w-16 bg-white border border-indigo-300 rounded px-2 py-1 text-center font-mono font-black text-slate-800 focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 transition-all" />
                       <span className="text-slate-400 font-black text-xs">%</span>
                    </div>
                 </div>

                 <div className="flex justify-between items-center py-2 text-indigo-700">
                    <span className="text-[10px] font-black uppercase tracking-widest">Rule 20 Liability</span>
                    <span className="font-mono font-black">R {formatCurrency(rule20CGT)}</span>
                 </div>
              </div>
           </div>

           <div className="bg-red-600 rounded-2xl p-8 flex flex-col justify-center items-center shadow-2xl border-b-8 border-red-800 text-white">
              <span className="text-red-200 text-[10px] font-black uppercase tracking-[0.3em] mb-2">Total CGT Liability</span>
              <div className="text-6xl font-mono font-black drop-shadow-lg">R {formatCurrency(totalLiability)}</div>
              <div className="mt-4 bg-white/10 px-4 py-2 rounded-full border border-white/10 flex items-center gap-2">
                 <Lock size={12} className="text-red-200" />
                 <span className="text-[10px] font-black uppercase tracking-widest text-white/80 italic">Synchronized to Estate Duty</span>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default CGTPage;


import React from 'react';
import { 
  BookOpen, Calculator, Landmark, ShieldCheck, 
  RefreshCcw, Info, CheckCircle2, AlertTriangle, Scale, Coins 
} from 'lucide-react';

// Fix: Move helper components outside the main function and define explicit types
interface SectionHeaderProps {
  icon: React.ElementType;
  title: string;
  color: string;
}

const SectionHeader: React.FC<SectionHeaderProps> = ({ icon: Icon, title, color }) => (
  <div className={`flex items-center gap-3 mb-6 ${color}`}>
    <div className="p-2 bg-white rounded-lg shadow-sm border border-slate-100">
      <Icon size={24} />
    </div>
    <h3 className="text-xl font-black uppercase tracking-tight">{title}</h3>
  </div>
);

interface InfoCardProps {
  title: string;
  icon: React.ElementType;
  color?: string;
  children: React.ReactNode;
}

const InfoCard: React.FC<InfoCardProps> = ({ title, children, icon: Icon, color = "bg-white" }) => (
  <div className={`${color} rounded-2xl p-6 border border-slate-200 shadow-sm space-y-3`}>
    <div className="flex items-center gap-2 mb-2">
      <Icon size={18} className="text-slate-400" />
      <h4 className="text-xs font-black uppercase tracking-widest text-slate-800">{title}</h4>
    </div>
    <div className="text-sm text-slate-600 leading-relaxed space-y-2">
      {children}
    </div>
  </div>
);

const Tip: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="bg-emerald-50 border-l-4 border-emerald-500 p-4 rounded-r-xl flex gap-3">
    <CheckCircle2 className="text-emerald-500 shrink-0" size={18} />
    <p className="text-[11px] font-bold text-emerald-800 uppercase tracking-tight leading-relaxed">
      {children}
    </p>
  </div>
);

const Warning: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded-r-xl flex gap-3">
    <AlertTriangle className="text-red-500 shrink-0" size={18} />
    <p className="text-[11px] font-bold text-red-800 uppercase tracking-tight leading-relaxed">
      {children}
    </p>
  </div>
);

const UserManualPage: React.FC = () => {
  return (
    <div className="space-y-16 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-40">
      {/* Introduction */}
      <div className="bg-slate-900 rounded-3xl p-12 text-white relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 p-10 opacity-10 pointer-events-none">
          <BookOpen size={200} />
        </div>
        <div className="relative z-10 max-w-2xl">
          <h1 className="text-5xl font-black uppercase tracking-tighter mb-4">Calculations Guide</h1>
          <p className="text-slate-400 text-lg leading-relaxed">
            Welcome to the 88 Wealth Management Estate Duty Suite. This manual provides detailed guidance on the methodology, 
            synchronization logic, and statutory requirements integrated into this application.
          </p>
        </div>
      </div>

      {/* Core Logic Section */}
      <section>
        <SectionHeader icon={RefreshCcw} title="Synchronization Logic" color="text-emerald-600" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <InfoCard title="The Farm Discrepancy" icon={Landmark}>
            <p>One of the most specialized parts of this tool is how it handles Agricultural Property (Farms):</p>
            <ul className="list-disc ml-5 space-y-1">
              <li><strong>Estate Duty:</strong> Farms are valued at 70% of market value as per Section 1(1).</li>
              <li><strong>CGT:</strong> The full 100% Market Value is used as the proceeds for Capital Gains Tax calculations.</li>
            </ul>
            <Tip>The app automatically manages this split. You only enter the 100% Market Value on the Estate Duty page once.</Tip>
          </InfoCard>

          <InfoCard title="Data Flow" icon={RefreshCcw}>
            <p>Data entered in the <strong>ESTATE DUTY</strong> page flows automatically to:</p>
            <ul className="list-disc ml-5 space-y-1">
              <li><strong>CGT Page:</strong> For gains analysis and base cost determination.</li>
              <li><strong>Executors Fees:</strong> To determine the fee base (Gross Estate minus certain deductions).</li>
              <li><strong>Cash Page:</strong> To analyze liquidity and deficits.</li>
            </ul>
            <Warning>Manually changing linked values on the CGT page is not allowed to maintain data integrity across the estate report.</Warning>
          </InfoCard>
        </div>
      </section>

      {/* Page by Page Section */}
      <section>
        <SectionHeader icon={Calculator} title="Page-by-Page Guidance" color="text-slate-800" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <InfoCard title="Estate Duty Page" icon={Scale}>
            <p>This is your primary entry point. Start by naming the beneficiary/estate in the header.</p>
            <p>Use the "Add Farm" button for multiple agricultural properties. All values should be current Market Values.</p>
          </InfoCard>

          <InfoCard title="CGT Module" icon={Landmark}>
            <p>Here you define the <strong>Base Cost</strong> for each synced asset. The proceeds are pulled from your asset entries.</p>
            <Tip>We have increased the Annual Exclusion to <strong>R300,000</strong> to reflect the death-year allowance.</Tip>
          </InfoCard>

          <InfoCard title="Executors Fees" icon={Calculator}>
            <p>Calculates the statutory fee (currently 3.5%). You can run "What If" scenarios to see the impact of negotiated lower fees.</p>
          </InfoCard>

          <InfoCard title="Married Out of Community" icon={Scale}>
            <p>Specific to marriage with accrual. You must enter the <strong>Initial Value</strong>, growth rates (CPI), and the <strong>Term</strong> of the marriage.</p>
          </InfoCard>

          <InfoCard title="Cash (Liquidity)" icon={Coins}>
            <p>A critical feasibility check. Shows whether the estate has enough liquid cash to pay duties, liabilities, and legacies without selling illiquid assets.</p>
          </InfoCard>

          <InfoCard title="Summary & Report" icon={ShieldCheck}>
            <p>Generates a formal <strong>Annexure A</strong> for client presentation. All notes are automatically appended based on current law and your entries.</p>
          </InfoCard>
        </div>
      </section>

      {/* Pro Tips Section */}
      <section className="bg-slate-100 rounded-3xl p-10 border border-slate-200">
        <div className="flex items-center gap-3 mb-8">
          <Info className="text-slate-900" size={24} />
          <h3 className="text-xl font-black uppercase tracking-tight text-slate-900">Advanced Usage Tips</h3>
        </div>
        <div className="space-y-6">
          <div className="flex gap-4">
             <div className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center font-black text-xs shrink-0 mt-1">1</div>
             <div>
                <h5 className="font-black text-xs uppercase tracking-widest text-slate-900 mb-2">Section 4A Rebate</h5>
                <p className="text-sm text-slate-600">The statutory rebate is set to R3.5m by default but is editable on the Estate Duty page to allow for porting of unused rebates from a deceased spouse.</p>
             </div>
          </div>
          <div className="flex gap-4">
             <div className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center font-black text-xs shrink-0 mt-1">2</div>
             <div>
                <h5 className="font-black text-xs uppercase tracking-widest text-slate-900 mb-2">Printing the Report</h5>
                <p className="text-sm text-slate-600">Navigate to the <strong>SUMMARY</strong> page and use the "Print" button. The report is optimized for A4 paper and hides all UI elements during printing.</p>
             </div>
          </div>
          <div className="flex gap-4">
             <div className="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center font-black text-xs shrink-0 mt-1">3</div>
             <div>
                <h5 className="font-black text-xs uppercase tracking-widest text-slate-900 mb-2">Residue Calculation</h5>
                <p className="text-sm text-slate-600">The <strong>REMAINS</strong> page calculates the actual residue after all debts, taxes, and specific legacies. This is the amount available for residuary heirs.</p>
             </div>
          </div>
        </div>
      </section>

      <footer className="text-center py-10 border-t border-slate-200">
         <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em]">88 Wealth Management • Internal Documentation • v1.4.2</p>
      </footer>
    </div>
  );
};

export default UserManualPage;

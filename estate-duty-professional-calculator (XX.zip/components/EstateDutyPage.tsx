
import React from 'react';
import { 
  Farm, 
  LivestockState, 
  MiscellaneousState, 
  BusinessInterestsState, 
  ResidentialState,
  VehicleState,
  CashState,
  InvestmentState,
  LoanAccountState,
  OtherState,
  PolicyState,
  DeductionState,
  Art4qState
} from '../types';
import { Plus, Trash2, TrendingUp, ShieldCheck, Scale, Heart, Calculator, Info, Lock, Link as LinkIcon, RefreshCw, Zap } from 'lucide-react';

interface InputFieldProps {
  label: string;
  value: number;
  onChange?: (val: number) => void;
  nameField?: {
    value: string;
    onChange: (val: string) => void;
    className?: string;
  } | null;
  labelColor?: string;
  bg?: string;
  readOnly?: boolean;
  syncType?: 'SYNC' | 'CALC' | 'AUTO';
}

const InputField: React.FC<InputFieldProps> = ({ 
  label, 
  value, 
  onChange, 
  nameField = null, 
  labelColor = "text-slate-700", 
  bg = "bg-white",
  readOnly = false,
  syncType = 'SYNC'
}) => {
  // Enhanced visual cues for automated fields
  const isSynced = syncType === 'SYNC' && readOnly;
  const isCalculated = syncType === 'CALC' && readOnly;

  const containerBg = isSynced 
    ? 'bg-amber-50/30' 
    : isCalculated 
    ? 'bg-indigo-50/30' 
    : 'hover:bg-slate-50/50';

  const inputBg = isSynced 
    ? 'bg-amber-50/60' 
    : isCalculated 
    ? 'bg-indigo-50/60' 
    : bg;

  const inputBorder = isSynced 
    ? 'border-amber-200' 
    : isCalculated 
    ? 'border-indigo-200' 
    : 'border-slate-200';

  const textColor = isSynced 
    ? 'text-amber-900' 
    : isCalculated 
    ? 'text-indigo-900' 
    : 'text-slate-800';

  const badgeColor = isSynced 
    ? 'bg-amber-600' 
    : 'bg-indigo-600';

  const labelTextColor = isSynced 
    ? 'text-amber-900' 
    : isCalculated 
    ? 'text-indigo-900' 
    : labelColor;

  return (
    <div className={`flex flex-col sm:flex-row sm:items-center justify-between py-4 border-b border-slate-100 group transition-colors ${containerBg} px-3 md:px-4`}>
      <div className="flex-1 flex flex-col gap-1.5 mb-3 sm:mb-0 w-full overflow-hidden">
        <div className="flex flex-wrap items-center gap-2">
          <label className={`${labelTextColor} font-black text-[10px] sm:text-xs uppercase tracking-widest flex items-center gap-2 truncate`}>
            {label}
            {readOnly && (
              <div className={`flex items-center gap-1 ${badgeColor} text-white text-[7px] px-1.5 py-0.5 rounded shadow-sm uppercase font-black tracking-widest shrink-0`}>
                {isSynced ? <LinkIcon size={8} /> : <RefreshCw size={8} className="animate-spin-slow" />}
                {isSynced ? 'Linked' : 'Derived'}
              </div>
            )}
          </label>
        </div>
        {nameField && (
          <input
            type="text"
            value={nameField.value}
            onChange={(e) => nameField.onChange(e.target.value)}
            placeholder="Description..."
            disabled={readOnly}
            className={`w-full bg-slate-100/50 sm:bg-transparent border border-slate-200 sm:border-none sm:border-b sm:border-slate-200 group-hover:border-slate-300 focus:border-emerald-500 focus:outline-none rounded-lg sm:rounded-none px-3 sm:px-1 py-2 sm:py-0.5 text-[11px] sm:text-xs transition-all ${nameField.className || 'text-slate-500 italic font-bold'}`}
          />
        )}
      </div>
      <div className="relative w-full sm:w-56 md:w-64 shrink-0">
        <div className="absolute left-3 top-1/2 -translate-y-1/2 flex items-center gap-1 pointer-events-none">
          {isSynced && <LinkIcon size={10} className="text-amber-400" />}
          {isCalculated && <Zap size={10} className="text-indigo-400" />}
          <span className={`${readOnly ? (isSynced ? 'text-amber-400' : 'text-indigo-400') : 'text-slate-400'} text-xs font-bold`}>R</span>
        </div>
        <input
          type="text"
          inputMode="numeric"
          value={value === 0 && !readOnly ? '' : value.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 }).replace(/,/g, '')}
          onChange={(e) => {
            if (readOnly || !onChange) return;
            const val = e.target.value.replace(/[^0-9.]/g, '');
            onChange(val === '' ? 0 : parseFloat(val));
          }}
          readOnly={readOnly}
          placeholder="0"
          className={`w-full ${inputBg} ${inputBorder} border rounded-xl ${readOnly ? 'pl-10' : 'pl-8'} pr-4 py-2.5 sm:py-3 text-right font-mono font-black ${textColor} focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all shadow-sm text-sm sm:text-base`}
        />
      </div>
    </div>
  );
};

interface EstateDutyPageProps {
  farms: Farm[];
  setFarms: React.Dispatch<React.SetStateAction<Farm[]>>;
  livestock: LivestockState;
  setLivestock: React.Dispatch<React.SetStateAction<LivestockState>>;
  misc: MiscellaneousState;
  setMisc: React.Dispatch<React.SetStateAction<MiscellaneousState>>;
  business: BusinessInterestsState;
  setBusiness: React.Dispatch<React.SetStateAction<BusinessInterestsState>>;
  residential: ResidentialState;
  setResidential: React.Dispatch<React.SetStateAction<ResidentialState>>;
  vehicles: VehicleState;
  setVehicles: React.Dispatch<React.SetStateAction<VehicleState>>;
  cash: CashState;
  setCash: React.Dispatch<React.SetStateAction<CashState>>;
  investments: InvestmentState;
  setInvestments: React.Dispatch<React.SetStateAction<InvestmentState>>;
  loans: LoanAccountState;
  setLoans: React.Dispatch<React.SetStateAction<LoanAccountState>>;
  other: OtherState;
  setOther: React.Dispatch<React.SetStateAction<OtherState>>;
  policies: PolicyState;
  setPolicies: React.Dispatch<React.SetStateAction<PolicyState>>;
  deductions: DeductionState;
  setDeductions: React.Dispatch<React.SetStateAction<DeductionState>>;
  art4q: Art4qState;
  setArt4q: React.Dispatch<React.SetStateAction<Art4qState>>;
  art4aRebate: number;
  setArt4aRebate: React.Dispatch<React.SetStateAction<number>>;
  clientName: string;
  autoExecutorsFee: number;
  totalGrossGain: number;
  accrualClaim: number;
}

const EstateDutyPage: React.FC<EstateDutyPageProps> = ({ 
  farms, setFarms, livestock, setLivestock, misc, setMisc, business, setBusiness,
  residential, setResidential, vehicles, setVehicles, cash, setCash,
  investments, setInvestments, loans, setLoans, other, setOther,
  policies, setPolicies, deductions, setDeductions,
  art4q, setArt4q, art4aRebate, setArt4aRebate,
  clientName,
  autoExecutorsFee,
  totalGrossGain,
  accrualClaim
}) => {
  const addFarm = () => {
    const newFarm: Farm = { id: crypto.randomUUID(), name: '', marketValue: 0, baseCost: 0 };
    setFarms([...farms, newFarm]);
  };

  const removeFarm = (id: string) => {
    setFarms(farms.filter(f => f.id !== id));
  };

  const updateFarm = (id: string, updates: Partial<Farm>) => {
    setFarms(farms.map(f => (f.id === id ? { ...f, ...updates } : f)));
  };

  const formatCurrency = (num: number) => {
    return num.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 });
  };

  const totalFarms70 = farms.reduce((sum, f) => sum + (f.marketValue || 0) * 0.7, 0);
  const totalLivestock = (Object.values(livestock) as number[]).reduce((a, b) => a + (b || 0), 0);
  const totalMisc = (Object.values(misc) as number[]).reduce((a, b) => a + (b || 0), 0);
  const totalBusiness = (business.soleProprietorship || 0) + (business.partnership || 0) + (business.ccInterest || 0) + (business.companyShares || 0);
  const totalResidential = (residential.property1 || 0) + (residential.property2 || 0) + (residential.holidayHome || 0) + (residential.householdEffects || 0);
  const totalVehicles = (vehicles.v1.value || 0) + (vehicles.v2.value || 0) + (vehicles.v3.value || 0);
  const totalCash = (cash.onCall || 0) + (cash.moneyMarket || 0);
  const totalInvestments = (investments.shares || 0) + (investments.unitTrusts || 0);
  const totalLoans = (loans.creditLoans || 0);
  const totalOther = (other.o1.value || 0) + (other.o2.value || 0) + (other.o3.value || 0) + (other.o4.value || 0) + (other.o5.value || 0) + totalGrossGain;
  const totalGroup1Assets = totalFarms70 + totalLivestock + totalMisc + totalBusiness + totalResidential + totalVehicles + totalCash + totalInvestments + totalLoans + totalOther;
  const totalPolicies = (Object.values(policies) as number[]).reduce((a, b) => a + (b || 0), 0);
  const grossEstate = totalGroup1Assets + totalPolicies;
  const totalDeductions = (deductions.mastersFees || 0) + (deductions.funeral || 0) + autoExecutorsFee + (deductions.liabilities || 0) + (deductions.cgt || 0) + accrualClaim;
  const totalArt4q = (art4q.usufruct || 0) + (art4q.wife || 0) + (art4q.husband || 0) + (policies.spouse || 0) + (art4q.vehicles || 0) + (art4q.miscValue || 0) + (art4q.residential || 0) + (art4q.household || 0) + (art4q.other || 0);
  const netEstate = grossEstate - totalDeductions - totalArt4q;
  const taxableEstate = Math.max(0, netEstate - art4aRebate);
  let estateDuty = 0;
  if (taxableEstate <= 30000000) estateDuty = taxableEstate * 0.20;
  else estateDuty = (30000000 * 0.20) + ((taxableEstate - 30000000) * 0.25);

  return (
    <div className="space-y-10 pb-56 animate-in fade-in slide-in-from-bottom-4 duration-700 max-w-full overflow-x-hidden">
      {/* Farm Property Section */}
      <section className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="bg-slate-800 p-5 md:p-6 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3 w-full md:w-auto">
            <div className="p-3 bg-emerald-500/20 rounded-xl shrink-0">
              <TrendingUp className="text-emerald-400 w-5 h-5 md:w-6 md:h-6" />
            </div>
            <div>
              <h3 className="text-white font-black text-sm md:text-lg uppercase tracking-widest leading-none">Farm Properties</h3>
              <p className="text-slate-500 text-[9px] md:text-xs mt-1 uppercase font-bold tracking-widest">Section 1(1) Valuation @ 70%</p>
            </div>
          </div>
          <div className="bg-slate-900/50 px-4 py-3 md:px-6 md:py-4 rounded-xl md:rounded-2xl border border-slate-700 w-full md:w-auto flex flex-col items-center md:items-end shadow-inner">
            <span className="text-slate-500 text-[8px] md:text-[9px] uppercase font-black block mb-0.5 md:mb-1 tracking-widest">TOTAL DUTY VALUE (70%)</span>
            <div className="text-xl md:text-2xl font-mono font-black text-emerald-400">
              R {formatCurrency(totalFarms70)}
            </div>
          </div>
        </div>
        
        <div className="p-4 md:p-8">
          {/* Mobile Card View for Farms */}
          <div className="md:hidden space-y-5">
             {farms.map((farm) => (
               <div key={farm.id} className="bg-slate-50 border border-slate-200 rounded-2xl p-4 sm:p-6 relative shadow-sm">
                  <button 
                    onClick={() => removeFarm(farm.id)} 
                    className="absolute top-4 right-4 text-slate-300 hover:text-red-500 transition-colors p-1"
                  >
                    <Trash2 size={16}/>
                  </button>
                  <div className="space-y-4">
                    <div>
                      <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest block mb-1.5">NAME / DESCRIPTION</label>
                      <input 
                        type="text" 
                        value={farm.name} 
                        placeholder="Property name..." 
                        onChange={(e) => updateFarm(farm.id, { name: e.target.value })} 
                        className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2.5 font-bold text-slate-800 focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 text-sm" 
                      />
                    </div>
                    <div className="flex flex-col gap-4">
                      <div className="flex-1">
                        <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest block mb-1.5">MARKET VALUE (100%)</label>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-xs font-bold">R</span>
                          <input 
                            type="text" 
                            inputMode="numeric" 
                            value={farm.marketValue === 0 ? '' : farm.marketValue.toString()} 
                            onChange={(e) => {
                              const val = e.target.value.replace(/[^0-9.]/g, '');
                              updateFarm(farm.id, { marketValue: val === '' ? 0 : parseFloat(val) });
                            }} 
                            className="w-full bg-white border border-slate-200 rounded-xl pl-8 pr-4 py-2.5 font-mono font-black text-slate-800 text-sm focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500" 
                          />
                        </div>
                      </div>
                      <div className="bg-indigo-600/5 rounded-xl border border-indigo-100/50 p-3 flex flex-col">
                        <label className="text-[8px] font-black text-indigo-400 uppercase tracking-widest block mb-0.5">SARS VALUE (70%)</label>
                        <div className="font-mono font-black text-indigo-700 text-base">R {formatCurrency(farm.marketValue * 0.7)}</div>
                      </div>
                    </div>
                  </div>
               </div>
             ))}
          </div>

          {/* Desktop Table View for Farms */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] border-b border-slate-100">
                  <th className="pb-4 w-1/2">NAME / DESCRIPTION</th>
                  <th className="pb-4">MARKET VALUE (100%)</th>
                  <th className="pb-4 text-right">DUTY VALUE (70%)</th>
                  <th className="pb-4 w-12"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {farms.map((farm) => (
                  <tr key={farm.id} className="group hover:bg-slate-50/50 transition-colors">
                    <td className="py-5">
                      <input type="text" value={farm.name} placeholder="Property Details..." onChange={(e) => updateFarm(farm.id, { name: e.target.value })} className="w-full bg-transparent border-none focus:ring-0 font-bold text-slate-700 uppercase" />
                    </td>
                    <td className="py-5">
                      <div className="flex items-center gap-1 font-mono font-bold">
                        <span className="text-slate-300 text-sm">R</span>
                        <input type="text" inputMode="numeric" value={farm.marketValue === 0 ? '' : farm.marketValue.toString()} onChange={(e) => {
                            const val = e.target.value.replace(/[^0-9.]/g, '');
                            updateFarm(farm.id, { marketValue: val === '' ? 0 : parseFloat(val) });
                          }} className="bg-transparent border-none focus:ring-0 p-0 w-full font-black text-slate-800" />
                      </div>
                    </td>
                    <td className="py-5 text-right font-mono font-black text-indigo-600 bg-indigo-50/30 px-4 rounded-xl border border-indigo-100/50">
                      R {formatCurrency(farm.marketValue * 0.7)}
                    </td>
                    <td className="py-5 text-right">
                      <button onClick={() => removeFarm(farm.id)} className="text-slate-300 hover:text-red-500 transition-colors p-2"><Trash2 size={18}/></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <button onClick={addFarm} className="mt-6 md:mt-8 w-full flex items-center justify-center gap-3 text-emerald-600 text-[10px] font-black uppercase tracking-[0.2em] border-2 border-dashed border-emerald-100 py-3.5 md:py-4 rounded-2xl hover:bg-emerald-50 hover:border-emerald-200 transition-all active:scale-[0.99]">
            <Plus size={16} className="stroke-[3]" /> Add Farm Property
          </button>
        </div>
      </section>

      {/* Asset Sections List */}
      <div className="grid grid-cols-1 gap-10">
        {[
          { title: "Livestock & Game", total: (Object.values(livestock) as number[]).reduce((a, b) => a + (b || 0), 0), color: "bg-slate-700", fields: [
            { label: "Cattle", value: livestock.cattle, onChange: (v: number) => setLivestock({...livestock, cattle: v}) },
            { label: "Sheep", value: livestock.sheep, onChange: (v: number) => setLivestock({...livestock, sheep: v}) },
            { label: "Game", value: livestock.game, onChange: (v: number) => setLivestock({...livestock, game: v}) },
          ]},
          { title: "Miscellaneous Assets", total: (Object.values(misc) as number[]).reduce((a, b) => a + (b || 0), 0), color: "bg-slate-700", fields: [
            { label: "Various", value: misc.misc, onChange: (v: number) => setMisc({...misc, misc: v}) },
            { label: "Farm Implements", value: misc.implements, onChange: (v: number) => setMisc({...misc, implements: v}) },
            { label: "Crop on land", value: misc.crops, onChange: (v: number) => setMisc({...misc, crops: v}) },
          ]},
          { title: "Business Interests", total: (business.soleProprietorship || 0) + (business.partnership || 0) + (business.ccInterest || 0) + (business.companyShares || 0), color: "bg-slate-700", fields: [
            { label: "Sole Proprietorship", value: business.soleProprietorship, onChange: (v: number) => setBusiness({...business, soleProprietorship: v}) },
            { label: "Partnership", value: business.partnership, onChange: (v: number) => setBusiness({...business, partnership: v}) },
            { label: "CC Interest", value: business.ccInterest, onChange: (v: number) => setBusiness({...business, ccInterest: v}) },
            { label: "Company Shares", value: business.companyShares, onChange: (v: number) => setBusiness({...business, companyShares: v}) },
          ]},
          { title: "Residential Assets", total: (residential.property1 || 0) + (residential.property2 || 0) + (residential.holidayHome || 0) + (residential.householdEffects || 0), color: "bg-slate-700", fields: [
            { label: "Property 1", value: residential.property1, onChange: (v: number) => setResidential({...residential, property1: v}), nameField: { value: residential.property1Name, onChange: (v: string) => setResidential({...residential, property1Name: v}) } },
            { label: "Property 2", value: residential.property2, onChange: (v: number) => setResidential({...residential, property2: v}), nameField: { value: residential.property2Name, onChange: (v: string) => setResidential({...residential, property2Name: v}) } },
            { label: "Holiday Home", value: residential.holidayHome, onChange: (v: number) => setResidential({...residential, holidayHome: v}) },
            { label: "Household Effects", value: residential.householdEffects, onChange: (v: number) => setResidential({...residential, householdEffects: v}) },
          ]},
          { title: "Vehicles", total: (vehicles.v1.value || 0) + (vehicles.v2.value || 0) + (vehicles.v3.value || 0), color: "bg-slate-700", fields: [
            { label: "Vehicle 1", value: vehicles.v1.value, onChange: (v: number) => setVehicles({...vehicles, v1: {...vehicles.v1, value: v}}), nameField: { value: vehicles.v1.name, onChange: (v: string) => setVehicles({...vehicles, v1: {...vehicles.v1, name: v}}) } },
            { label: "Vehicle 2", value: vehicles.v2.value, onChange: (v: number) => setVehicles({...vehicles, v2: {...vehicles.v2, value: v}}), nameField: { value: vehicles.v2.name, onChange: (v: string) => setVehicles({...vehicles, v2: {...vehicles.v2, name: v}}) } },
            { label: "Vehicle 3", value: vehicles.v3.value, onChange: (v: number) => setVehicles({...vehicles, v3: {...vehicles.v3, value: v}}), nameField: { value: vehicles.v3.name, onChange: (v: string) => setVehicles({...vehicles, v3: {...vehicles.v3, name: v}}) } },
          ]},
          { title: "Cash Assets", total: (cash.onCall || 0) + (cash.moneyMarket || 0), color: "bg-slate-700", fields: [
            { label: "On Call Accounts", value: cash.onCall, onChange: (v: number) => setCash({...cash, onCall: v}) },
            { label: "Money Market", value: cash.moneyMarket, onChange: (v: number) => setCash({...cash, moneyMarket: v}) },
          ]},
          { title: "Investments", total: (investments.shares || 0) + (investments.unitTrusts || 0), color: "bg-slate-700", fields: [
            { label: "Shares", value: investments.shares, onChange: (v: number) => setInvestments({...investments, shares: v}) },
            { label: "Unit Trusts", value: investments.unitTrusts, onChange: (v: number) => setInvestments({...investments, unitTrusts: v}) },
          ]},
          { title: "Other Assets", total: totalOther, color: "bg-slate-700", fields: [
            { label: "Total Capital Gain", value: totalGrossGain, readOnly: true, syncType: 'CALC' },
            { label: "Other 1", value: other.o1.value, onChange: (v: number) => setOther({...other, o1: {...other.o1, value: v}}), nameField: { value: other.o1.name, onChange: (v: string) => setOther({...other, o1: {...other.o1, name: v}}), className: "text-red-600 font-black uppercase text-[10px]" } },
            { label: "Other 2", value: other.o2.value, onChange: (v: number) => setOther({...other, o2: {...other.o2, value: v}}), nameField: { value: other.o2.name, onChange: (v: string) => setOther({...other, o2: {...other.o2, name: v}}) } },
          ]},
        ].map((section, idx) => (
          <section key={idx} className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <div className={`${section.color} px-4 py-4 md:px-6 md:py-5 flex flex-col sm:flex-row justify-between items-center text-white gap-3 md:gap-4`}>
              <h3 className="font-black uppercase tracking-[0.2em] text-[10px] sm:text-xs text-center sm:text-left">{section.title}</h3>
              <div className="text-lg md:text-xl font-mono font-black text-emerald-400">R {formatCurrency(section.total as number)}</div>
            </div>
            <div className="bg-slate-50/20 divide-y divide-slate-100">
              {section.fields.map((field, fIdx) => (
                <InputField key={fIdx} {...(field as any)} />
              ))}
            </div>
          </section>
        ))}

        <section className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="bg-slate-800 px-4 py-4 md:px-6 md:py-5 flex flex-col sm:flex-row justify-between items-center text-white gap-3 md:gap-4">
            <h3 className="font-black uppercase tracking-[0.2em] text-[10px] sm:text-xs flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" /> Policies & Insurance
            </h3>
            <div className="text-lg md:text-xl font-mono font-black text-emerald-400">R {formatCurrency(totalPolicies)}</div>
          </div>
          <div className="bg-slate-50/20 divide-y divide-slate-100">
            <InputField label="Spouse" value={policies.spouse} onChange={(v: number) => setPolicies({...policies, spouse: v})} />
            <InputField label="Third Parties" value={policies.thirdParties} onChange={(v: number) => setPolicies({...policies, thirdParties: v})} />
            <InputField label="Estate" value={policies.estate} onChange={(v: number) => setPolicies({...policies, estate: v})} />
            <InputField label="CV 3rd Parties" value={policies.cashValues3rd} onChange={(v: number) => setPolicies({...policies, cashValues3rd: v})} />
            <InputField label="Ceded Policies" value={policies.ceded} onChange={(v: number) => setPolicies({...policies, ceded: v})} />
            <InputField label="Death Val. (Spouse)" value={policies.deathValuesSpouse} onChange={(v: number) => setPolicies({...policies, deathValuesSpouse: v})} />
          </div>
        </section>

        <div className="bg-slate-950 rounded-3xl p-6 md:p-12 flex flex-col md:flex-row justify-between items-center shadow-2xl text-white border-l-8 border-emerald-500 overflow-hidden relative">
          <div className="absolute top-0 right-0 p-10 opacity-5 pointer-events-none">
             <TrendingUp size={200} />
          </div>
          <div className="mb-4 md:mb-0 text-center md:text-left relative z-10">
            <h2 className="text-2xl md:text-5xl font-black uppercase tracking-tighter text-emerald-400">Gross Estate</h2>
            <p className="text-slate-500 text-[8px] md:text-xs font-black uppercase tracking-[0.4em] mt-1 md:mt-2">Aggregate Valuation Summary</p>
          </div>
          <div className="text-3xl md:text-7xl font-mono font-black text-white relative z-10 tabular-nums">
            R {formatCurrency(grossEstate)}
          </div>
        </div>

        <section className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="bg-rose-700 px-4 py-4 md:px-6 md:py-5 flex flex-col sm:flex-row justify-between items-center text-white gap-3 md:gap-4">
            <h3 className="font-black uppercase tracking-[0.2em] text-[10px] sm:text-xs flex items-center gap-2">
              <Scale className="w-5 h-5" /> Statutory Deductions
            </h3>
            <div className="text-lg md:text-xl font-mono font-black text-rose-100">R {formatCurrency(totalDeductions)}</div>
          </div>
          <div className="bg-rose-50/10 divide-y divide-slate-100">
            <InputField label="Master's Fees" value={deductions.mastersFees} onChange={(v: number) => setDeductions({...deductions, mastersFees: v})} />
            <InputField label="Funeral Expenses" value={deductions.funeral} onChange={(v: number) => setDeductions({...deductions, funeral: v})} />
            <InputField label="Executor's Fee" value={autoExecutorsFee} readOnly={true} syncType="CALC" />
            <InputField label="Accrual Claim (M.O.C.)" value={accrualClaim} readOnly={true} syncType="SYNC" />
            <InputField label="Liabilities" value={deductions.liabilities} onChange={(v: number) => setDeductions({...deductions, liabilities: v})} />
            <InputField label="CGT" value={deductions.cgt} readOnly={true} syncType="SYNC" />
          </div>
        </section>

        <section className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="bg-rose-900 px-4 py-4 md:px-6 md:py-5 flex flex-col sm:flex-row justify-between items-center text-white gap-3 md:gap-4">
            <h3 className="font-black uppercase tracking-[0.2em] text-[10px] sm:text-xs flex items-center gap-2">
              <Heart className="w-5 h-5 fill-rose-300 stroke-none" /> Sec 4(q) Spousal Bequests
            </h3>
            <div className="text-lg md:text-xl font-mono font-black text-rose-100">R {formatCurrency(totalArt4q)}</div>
          </div>
          <div className="bg-rose-50/10 divide-y divide-slate-100">
            <InputField label="Usufruct" value={art4q.usufruct} onChange={(v: number) => setArt4q({...art4q, usufruct: v})} />
            <InputField label="Policies" value={policies.spouse} readOnly={true} syncType="SYNC" />
            <InputField label="Miscellaneous" value={art4q.miscValue} onChange={(v: number) => setArt4q({...art4q, miscValue: v})} nameField={{ value: art4q.miscDescription, onChange: (v: string) => setArt4q({...art4q, miscDescription: v}) }} />
          </div>
        </section>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="bg-white border-2 border-slate-100 rounded-3xl p-6 md:p-12 shadow-sm text-center">
            <div className="text-slate-400 font-black uppercase tracking-[0.3em] text-[9px] md:text-[10px] mb-4">Net Estate Value</div>
            <div className="text-2xl md:text-5xl font-mono font-black text-red-600 tabular-nums">R {formatCurrency(netEstate)}</div>
          </div>
          <div className="bg-white border-2 border-slate-100 rounded-3xl p-6 md:p-12 shadow-sm flex flex-col justify-center items-center">
            <div className="text-slate-400 font-black uppercase tracking-[0.3em] text-[9px] md:text-[10px] mb-4">Sec 4A Statutory Rebate</div>
            <div className="relative w-full max-w-[280px]">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-black text-sm">R</span>
              <input type="text" inputMode="numeric" value={art4aRebate.toString()} onChange={(e) => {
                  const val = e.target.value.replace(/[^0-9.]/g, '');
                  setArt4aRebate(val === '' ? 0 : parseFloat(val));
                }} className="w-full bg-slate-100/50 border-2 border-slate-200 rounded-2xl pl-8 pr-4 py-3 md:py-4 text-right font-mono font-black text-slate-800 focus:outline-none focus:ring-4 focus:ring-slate-300/10 focus:border-slate-400" />
            </div>
          </div>
        </div>

        {/* Final Duty Result */}
        <div className="bg-slate-900 rounded-[2rem] md:rounded-[3rem] p-6 md:p-16 shadow-2xl border-b-[12px] border-red-600 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none">
             <Calculator size={280} />
          </div>
          <div className="flex flex-col lg:flex-row justify-between items-center gap-8 md:gap-16 relative z-10">
            <div className="text-center lg:text-left">
              <div className="flex items-center justify-center lg:justify-start gap-3 md:gap-4 mb-3 md:mb-4">
                <div className="p-3 md:p-4 bg-red-600 rounded-xl md:rounded-2xl shadow-lg shadow-red-900/50">
                  <Calculator className="w-6 h-6 md:w-10 md:h-10 text-white" />
                </div>
                <h2 className="text-3xl md:text-6xl font-black text-white uppercase tracking-tighter">Estate Duty</h2>
              </div>
              <div className="flex items-center gap-2 md:gap-3 text-slate-400 text-[9px] md:text-xs font-black uppercase tracking-[0.3em] justify-center lg:justify-start">
                <Info size={14} className="text-emerald-500" />
                Taxable Balance: R {formatCurrency(taxableEstate)}
              </div>
            </div>
            <div className="text-center lg:text-right w-full lg:w-auto">
              <div className="text-4xl md:text-8xl font-mono font-black text-white drop-shadow-2xl tracking-tighter tabular-nums break-words">
                R {formatCurrency(estateDuty)}
              </div>
              <p className="text-red-500 text-[9px] md:text-xs font-black uppercase tracking-[0.5em] mt-3 md:mt-4 animate-pulse">Final Tax Liability</p>
            </div>
          </div>
        </div>
      </div>

      {/* Persistent Floating Footer for Mobile Sums */}
      <div className="fixed bottom-0 left-0 right-0 md:left-80 bg-slate-950/95 backdrop-blur-xl border-t-4 border-red-600 p-4 md:p-8 shadow-[0_-25px_50px_-12px_rgba(0,0,0,0.5)] z-[40] flex flex-col sm:flex-row justify-between items-center text-white gap-4 md:gap-6">
        <div className="hidden lg:block">
          <span className="text-red-500 text-[10px] font-black uppercase block tracking-[0.3em] mb-1">Estate Analysis Summary</span>
          <span className="text-slate-400 text-xs font-bold italic tracking-tight truncate max-w-[200px] block">Prepared for {clientName || '[CLIENT]'}</span>
        </div>
        <div className="flex items-center justify-between w-full lg:w-auto lg:gap-16">
          <div className="text-left lg:text-right lg:border-r lg:border-slate-800 lg:pr-16">
            <span className="text-slate-500 text-[8px] md:text-[9px] font-black uppercase block tracking-widest mb-0.5">Net Estate</span>
            <span className="text-base md:text-2xl font-mono font-black text-slate-200">R {formatCurrency(netEstate)}</span>
          </div>
          <div className="text-right">
            <span className="text-red-500 text-[8px] md:text-[9px] font-black uppercase block tracking-widest mb-0.5">Payable Duty</span>
            <div className="text-xl md:text-4xl font-mono font-black text-white tabular-nums">
              R {formatCurrency(estateDuty)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EstateDutyPage;

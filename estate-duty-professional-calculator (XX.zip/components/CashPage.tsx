
import React from 'react';
import { CashPageState } from '../types';
import { ArrowDownCircle, ArrowUpCircle, Info, Lock, PlusCircle, Link as LinkIcon } from 'lucide-react';

interface CashPageProps {
  clientName: string;
  cashFromAssets: number;
  estatePolicy: number;
  cededPolicy: number;
  liabilitiesAndCosts: number;
  estateDuty: number;
  cashPageState: CashPageState;
  setCashPageState: React.Dispatch<React.SetStateAction<CashPageState>>;
}

const CashPage: React.FC<CashPageProps> = ({
  clientName,
  cashFromAssets,
  estatePolicy,
  cededPolicy,
  liabilitiesAndCosts,
  estateDuty,
  cashPageState,
  setCashPageState
}) => {
  const formatCurrency = (num: number) => {
    return num.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 });
  };

  const handleNumericChange = (field: keyof CashPageState, val: string) => {
    const numericVal = val.replace(/[^0-9.]/g, '');
    const parsed = numericVal === '' ? 0 : parseFloat(numericVal);
    setCashPageState(prev => ({ ...prev, [field]: parsed }));
  };

  const totalAvailable = cashFromAssets + estatePolicy + cededPolicy + cashPageState.otherCash;
  const totalRequired = liabilitiesAndCosts + cashPageState.cashLegacies + estateDuty;
  const netPosition = totalAvailable - totalRequired;
  const isDeficit = netPosition < 0;

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-32">
      <div className="bg-slate-800 rounded-xl p-6 shadow-lg border-b-4 border-slate-600 text-white flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-black uppercase tracking-tight">Liquidity Analysis (Cash)</h2>
          <p className="text-slate-400 text-xs font-medium uppercase tracking-widest mt-1">Cash Flow & Estate Solvency</p>
        </div>
        <div className="text-right">
          <span className="text-slate-400 font-bold uppercase text-[10px] block tracking-widest mb-1">Estate</span>
          <span className="text-xl font-black uppercase border-b-2 border-slate-500/30 pb-1">{clientName || 'Unknown'}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col">
          <div className="bg-emerald-600 p-4 text-white flex justify-between items-center">
            <h3 className="font-black uppercase tracking-widest text-sm flex items-center gap-2">
              <ArrowUpCircle className="w-5 h-5" /> Cash Available
            </h3>
            <div className="text-lg font-mono font-black">R {formatCurrency(totalAvailable)}</div>
          </div>
          <div className="p-6 flex-1 space-y-4">
            <div className="flex justify-between items-center py-3 border-b border-indigo-50 bg-indigo-50/20 px-4 rounded-xl -mx-2">
              <span className="text-indigo-900 font-bold text-xs uppercase tracking-tight flex items-center gap-2">
                <LinkIcon size={12} className="text-indigo-400"/> Cash from Assets
              </span>
              <span className="font-mono font-black text-indigo-700 text-lg">R {formatCurrency(cashFromAssets)}</span>
            </div>
            <div className="flex justify-between items-center py-3 border-b border-indigo-50 bg-indigo-50/20 px-4 rounded-xl -mx-2">
              <span className="text-indigo-900 font-bold text-xs uppercase tracking-tight flex items-center gap-2">
                <LinkIcon size={12} className="text-indigo-400"/> Estate Policies
              </span>
              <span className="font-mono font-black text-indigo-700 text-lg">R {formatCurrency(estatePolicy)}</span>
            </div>
            <div className="flex justify-between items-center py-3 border-b border-indigo-50 bg-indigo-50/20 px-4 rounded-xl -mx-2">
              <span className="text-indigo-900 font-bold text-xs uppercase tracking-tight flex items-center gap-2">
                <LinkIcon size={12} className="text-indigo-400"/> Ceded Policies
              </span>
              <span className="font-mono font-black text-indigo-700 text-lg">R {formatCurrency(cededPolicy)}</span>
            </div>
            <div className="flex justify-between items-center py-3 px-2">
              <span className="text-slate-600 font-bold text-xs uppercase tracking-tight flex items-center gap-2">
                <PlusCircle size={12} className="text-emerald-500"/> Other Cash Available
              </span>
              <div className="flex items-center gap-2">
                <span className="text-slate-300 font-mono text-sm">R</span>
                <input
                  type="text"
                  inputMode="numeric"
                  value={cashPageState.otherCash === 0 ? '' : cashPageState.otherCash.toLocaleString().replace(/,/g, '')}
                  onChange={(e) => handleNumericChange('otherCash', e.target.value)}
                  placeholder="0"
                  className="bg-slate-50 border border-slate-200 rounded px-3 py-1 text-right w-32 font-mono font-black text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col">
          <div className="bg-red-600 p-4 text-white flex justify-between items-center">
            <h3 className="font-black uppercase tracking-widest text-sm flex items-center gap-2">
              <ArrowDownCircle className="w-5 h-5" /> Cash Required
            </h3>
            <div className="text-lg font-mono font-black">R {formatCurrency(totalRequired)}</div>
          </div>
          <div className="p-6 flex-1 space-y-4">
            <div className="flex justify-between items-center py-3 border-b border-indigo-50 bg-indigo-50/20 px-4 rounded-xl -mx-2">
              <span className="text-indigo-900 font-bold text-xs uppercase tracking-tight flex items-center gap-2">
                <LinkIcon size={12} className="text-indigo-400"/> Liabilities and Costs
              </span>
              <span className="font-mono font-black text-indigo-700 text-lg">R {formatCurrency(liabilitiesAndCosts)}</span>
            </div>
            <div className="flex justify-between items-center py-3 px-2">
              <span className="text-slate-600 font-bold text-xs uppercase tracking-tight flex items-center gap-2">
                <PlusCircle size={12} className="text-red-500"/> Cash Legacies
              </span>
              <div className="flex items-center gap-2">
                <span className="text-slate-300 font-mono text-sm">R</span>
                <input
                  type="text"
                  inputMode="numeric"
                  value={cashPageState.cashLegacies === 0 ? '' : cashPageState.cashLegacies.toLocaleString().replace(/,/g, '')}
                  onChange={(e) => handleNumericChange('cashLegacies', e.target.value)}
                  placeholder="0"
                  className="bg-slate-50 border border-slate-200 rounded px-3 py-1 text-right w-32 font-mono font-black text-slate-800 focus:outline-none focus:ring-2 focus:ring-red-500/20"
                />
              </div>
            </div>
            <div className="flex justify-between items-center py-3 border-b border-indigo-50 bg-indigo-50/20 px-4 rounded-xl -mx-2">
              <span className="text-indigo-900 font-bold text-xs uppercase tracking-tight flex items-center gap-2">
                <LinkIcon size={12} className="text-indigo-400"/> Estate Duty
              </span>
              <span className="font-mono font-black text-indigo-700 text-lg">R {formatCurrency(estateDuty)}</span>
            </div>
          </div>
        </div>
      </div>

      <div className={`${isDeficit ? 'bg-red-700' : 'bg-emerald-700'} rounded-2xl p-10 flex flex-col items-center justify-center shadow-2xl transition-colors duration-500`}>
        <div className="text-white/60 text-[10px] font-black uppercase tracking-[0.3em] mb-4">
          Current Cash Position (Deficit/Surplus)
        </div>
        <div className="text-7xl font-mono font-black text-white drop-shadow-lg text-center">
          {isDeficit ? '-' : ''}R {formatCurrency(Math.abs(netPosition))}
        </div>
        <div className="mt-8 flex items-center gap-4 bg-black/20 px-6 py-3 rounded-full border border-white/10">
          {isDeficit ? (
            <span className="text-red-300 font-black uppercase text-xs tracking-widest flex items-center gap-2">
               <Info size={16}/> Liquid Assets Insufficient to Cover Liabilities
            </span>
          ) : (
            <span className="text-emerald-300 font-black uppercase text-xs tracking-widest flex items-center gap-2">
               <Info size={16}/> Estate Maintains Sufficient Liquidity
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default CashPage;

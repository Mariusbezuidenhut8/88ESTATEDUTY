
import React, { useState, useMemo } from 'react';
import { PolicyState, ExecutorsFeesState } from '../types';
import { Calculator, Percent, MinusCircle, CheckCircle2, ArrowRight, Link as LinkIcon, Info, X, ShieldAlert, Clock, ChevronRight } from 'lucide-react';

interface ExecutorsFeesPageProps {
  clientName: string;
  grossEstate: number;
  policies: PolicyState;
  executorsFees: ExecutorsFeesState;
  setExecutorsFees: React.Dispatch<React.SetStateAction<ExecutorsFeesState>>;
  autoExecutorsFee: number;
}

const ExecutorsFeesPage: React.FC<ExecutorsFeesPageProps> = ({
  clientName,
  grossEstate,
  policies,
  executorsFees,
  setExecutorsFees,
  autoExecutorsFee
}) => {
  const [showDetails, setShowDetails] = useState(false);

  // Capture the generation timestamp when the component views
  const generationTimestamp = useMemo(() => {
    return new Date().toLocaleString('en-ZA', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    });
  }, []);

  const beneficiaryPolicies = (policies.spouse || 0) + (policies.thirdParties || 0);
  const deathValues3rd = policies.deathValues3rd || 0;
  
  const totalDeductions = beneficiaryPolicies + deathValues3rd;
  const baseForFees = Math.max(0, grossEstate - totalDeductions);
  
  const whatIfFee = autoExecutorsFee * (executorsFees.whatIfRate / 100);

  const formatCurrency = (num: number) => {
    return num.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 });
  };

  const handleRateChange = (field: 'feeRate' | 'whatIfRate', val: string) => {
    const numericVal = val.replace(/[^0-9.]/g, '');
    const parsed = numericVal === '' ? 0 : parseFloat(numericVal);
    setExecutorsFees(prev => ({ ...prev, [field]: parsed }));
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-32 sm:pb-20">
      {/* Detail Modal */}
      {showDetails && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-300">
          <div className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-2xl overflow-hidden border border-slate-200 animate-in zoom-in-95 duration-300">
            <div className="bg-slate-900 p-8 text-white relative">
              <button 
                onClick={() => setShowDetails(false)}
                className="absolute top-6 right-6 p-3 hover:bg-white/10 rounded-full transition-all active:scale-90"
              >
                <X size={24} />
              </button>
              <div className="flex items-center gap-4 mb-2">
                <div className="p-4 bg-emerald-500/20 rounded-2xl border border-emerald-500/30">
                  <Calculator size={32} className="text-emerald-400" />
                </div>
                <div>
                  <h3 className="text-2xl font-black uppercase tracking-tight">Calculation Breakdown</h3>
                  <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.3em] mt-1">Executor's Remuneration Base</p>
                </div>
              </div>
            </div>
            
            <div className="p-8 space-y-8">
              <div className="space-y-4">
                <p className="text-slate-600 text-sm font-medium leading-relaxed">
                  Executor's fees are calculated only on assets that require administration. Assets passing outside the estate do not attract fees.
                </p>

                <div className="bg-slate-50 rounded-3xl p-8 border-2 border-slate-100 space-y-6">
                  <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest text-slate-400">
                     <span>Components</span>
                     <span className="flex items-center gap-1 text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded"><LinkIcon size={10} /> Live Sync</span>
                  </div>
                  <div className="space-y-3">
                     <div className="flex justify-between items-center">
                        <span className="text-slate-900 font-black text-xs uppercase tracking-tight">Total Gross Estate</span>
                        <span className="font-mono font-black text-slate-900">R {formatCurrency(grossEstate)}</span>
                     </div>
                     <div className="flex justify-between items-center text-rose-600 font-bold italic text-sm">
                        <span className="flex items-center gap-2">
                          <MinusCircle size={14} /> Nominated Policies
                        </span>
                        <span className="font-mono font-black">- R {formatCurrency(beneficiaryPolicies)}</span>
                     </div>
                     <div className="flex justify-between items-center text-rose-600 font-bold italic text-sm">
                        <span className="flex items-center gap-2">
                          <MinusCircle size={14} /> 3rd Party Owned
                        </span>
                        <span className="font-mono font-black">- R {formatCurrency(deathValues3rd)}</span>
                     </div>
                     <div className="h-px bg-slate-200 my-4" />
                     <div className="flex justify-between items-center">
                        <span className="font-black uppercase tracking-tighter text-slate-900">Net Fee Base Value</span>
                        <span className="text-2xl font-mono font-black text-indigo-700">R {formatCurrency(baseForFees)}</span>
                     </div>
                  </div>
                </div>
              </div>

              <div className="bg-blue-50 border-l-4 border-blue-500 p-5 rounded-r-2xl flex gap-4">
                 <Info size={20} className="text-blue-500 shrink-0" />
                 <p className="text-[11px] text-blue-900 font-bold leading-relaxed uppercase tracking-tight">
                   Note: Life policies with nominated beneficiaries pass directly and are excluded from the liquidation and distribution account fee base.
                 </p>
              </div>

              <button 
                onClick={() => setShowDetails(false)}
                className="w-full bg-slate-900 hover:bg-slate-800 text-white font-black uppercase tracking-[0.2em] py-5 rounded-2xl transition-all shadow-xl shadow-slate-900/10 active:scale-[0.98]"
              >
                Accept Calculation
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="bg-slate-800 rounded-xl p-6 shadow-lg border-b-4 border-emerald-500 text-white flex flex-col md:flex-row justify-between items-center gap-4">
        <div>
          <h2 className="text-2xl font-black uppercase tracking-tight">Executor's Remuneration</h2>
          <p className="text-slate-400 text-xs font-medium uppercase tracking-widest mt-1">Fee Analysis & Performance Scenarios</p>
        </div>
        <div className="text-right flex flex-col items-center md:items-end">
          <span className="text-emerald-400 font-bold uppercase text-[10px] block tracking-widest mb-1">Estate: {clientName || 'Unknown'}</span>
          <div className="flex items-center gap-1.5 bg-slate-900/40 px-3 py-1.5 rounded-lg border border-slate-700/50">
             <Clock size={12} className="text-emerald-500/70" />
             <span className="text-[10px] font-mono font-bold text-slate-300 uppercase tracking-tight">
               Ref: {generationTimestamp}
             </span>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-[2rem] shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-6 md:p-10 space-y-10">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 flex flex-col justify-between group">
              <div className="flex justify-between items-start mb-4">
                <span className="text-slate-400 text-[10px] font-black uppercase tracking-widest">Total Gross Assets</span>
                <LinkIcon size={14} className="text-slate-300" />
              </div>
              <div className="text-2xl font-mono font-black text-slate-900">R {formatCurrency(grossEstate)}</div>
            </div>

            <div className="bg-rose-50/50 p-6 rounded-2xl border border-rose-100 flex flex-col justify-between">
              <div className="flex items-center justify-between mb-4">
                <span className="text-rose-500 text-[10px] font-black uppercase tracking-widest">Exempt from Fees</span>
                <MinusCircle size={16} className="text-rose-300" />
              </div>
              <div className="text-2xl font-mono font-black text-rose-600">R {formatCurrency(totalDeductions)}</div>
              <div className="mt-3 text-[9px] font-bold text-rose-400 uppercase tracking-tight flex items-center gap-1">
                 <ShieldAlert size={10} /> Policies passing direct to heirs
              </div>
            </div>

            <div className="bg-indigo-600 p-6 rounded-2xl shadow-xl shadow-indigo-500/10 flex flex-col justify-between text-white border-b-8 border-indigo-800 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
                 <Calculator size={60} />
              </div>
              <div className="flex items-center gap-2 mb-4">
                <span className="text-indigo-200 text-[10px] font-black uppercase tracking-widest">Fee Base Value</span>
                <button onClick={() => setShowDetails(true)} className="hover:text-white transition-colors p-1 bg-white/10 rounded-full">
                  <Info size={12} />
                </button>
              </div>
              <div className="text-2xl font-mono font-black tracking-tight">R {formatCurrency(baseForFees)}</div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white border-2 border-slate-50 rounded-2xl p-6 sm:p-8 shadow-sm hover:shadow-md transition-all">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8">
                <div className="flex items-start gap-4">
                  <div className="p-4 bg-slate-100 rounded-2xl text-slate-900 border border-slate-200">
                    <Percent size={24} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-slate-900 font-black uppercase text-sm tracking-widest">Statutory Remuneration</h3>
                      <button 
                        onClick={() => setShowDetails(true)}
                        className="text-slate-300 hover:text-indigo-600 transition-colors"
                      >
                        <Info size={16} />
                      </button>
                    </div>
                    <p className="text-slate-400 text-[9px] font-black uppercase tracking-widest mt-1">As per Government Gazette (Act 66 of 1965)</p>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-6">
                  <div className="flex items-center gap-3 bg-slate-50 border-2 border-slate-100 px-6 py-3 rounded-2xl">
                    <span className="text-slate-400 font-mono text-xs font-black">@</span>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={executorsFees.feeRate === 0 ? '' : executorsFees.feeRate.toString()}
                      onChange={(e) => handleRateChange('feeRate', e.target.value)}
                      className="w-16 bg-transparent text-center font-black text-slate-900 text-xl focus:outline-none"
                    />
                    <span className="text-slate-400 text-xs font-black">%</span>
                  </div>

                  <ArrowRight className="text-slate-200 hidden lg:block" />

                  <div className="bg-indigo-50 px-8 py-4 rounded-2xl border border-indigo-100 text-right min-w-[240px] flex flex-col justify-center shadow-inner">
                    <span className="text-indigo-400 text-[9px] font-black uppercase block tracking-widest mb-1">Fee Amount</span>
                    <div className="text-2xl font-mono font-black text-indigo-700">R {formatCurrency(autoExecutorsFee)}</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-slate-900 rounded-[2rem] p-6 sm:p-8 shadow-2xl relative overflow-hidden group">
              <div className="absolute inset-0 bg-red-600/5 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8 relative z-10">
                <div className="flex items-start gap-4">
                  <div className="p-4 bg-white/5 rounded-2xl text-red-500 border border-white/10">
                    <ShieldAlert size={24} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-white font-black uppercase text-sm tracking-widest">Scenario Optimization</h3>
                      <button 
                        onClick={() => setShowDetails(true)}
                        className="text-slate-600 hover:text-white transition-colors"
                      >
                        <Info size={16} />
                      </button>
                    </div>
                    <p className="text-slate-500 text-[9px] font-black uppercase tracking-widest mt-1">Negotiated Percentage on Standard Fee</p>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-6">
                  <div className="flex items-center gap-3 bg-white/5 border border-white/10 px-6 py-3 rounded-2xl focus-within:border-red-500/50 transition-all">
                    <span className="text-slate-500 font-mono text-xs font-black">@</span>
                    <input
                      type="text"
                      inputMode="decimal"
                      value={executorsFees.whatIfRate === 0 ? '' : executorsFees.whatIfRate.toString()}
                      onChange={(e) => handleRateChange('whatIfRate', e.target.value)}
                      className="w-20 bg-transparent text-center font-black text-white text-xl focus:outline-none"
                    />
                    <span className="text-slate-500 text-[10px] font-black uppercase tracking-tight">% OF FEE</span>
                  </div>

                  <ArrowRight className="text-slate-700 hidden lg:block" />

                  <div className="bg-white/5 px-8 py-4 rounded-2xl border border-white/10 text-right min-w-[240px] flex flex-col justify-center">
                    <span className="text-red-400 text-[9px] font-black uppercase block tracking-widest mb-1">Optimized Fee</span>
                    <div className="text-2xl font-mono font-black text-white">R {formatCurrency(whatIfFee)}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-slate-50 p-6 border-t border-slate-200 flex flex-col md:flex-row justify-between items-center gap-4 text-slate-500">
          <div className="flex items-center gap-3 text-[10px] font-black uppercase tracking-widest">
            <CheckCircle2 size={16} className="text-emerald-500" />
            <span>Statutory Remuneration is capped at 3.50% excl. VAT.</span>
          </div>
          <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-slate-400">
             Basis for Analysis: <span className="font-mono text-slate-600">R {formatCurrency(baseForFees)}</span>
          </div>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 md:left-80 bg-slate-950/95 backdrop-blur-xl border-t-4 border-emerald-500 p-6 shadow-[0_-25px_50px_-12px_rgba(0,0,0,0.5)] z-[40] flex justify-between items-center text-white">
        <div className="hidden sm:flex flex-col">
          <span className="text-emerald-500 text-[10px] font-black uppercase tracking-[0.3em] mb-1">Final Sync Result</span>
          <span className="text-slate-400 text-xs font-medium italic">Calculated for {clientName || 'Estate'}</span>
        </div>
        <div className="flex items-center gap-10">
          <div className="text-right">
            <span className="text-slate-500 text-[9px] font-black uppercase block tracking-widest mb-1">Estate Fee</span>
            <div className="text-3xl font-mono font-black text-white tabular-nums">
              R {formatCurrency(autoExecutorsFee)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExecutorsFeesPage;

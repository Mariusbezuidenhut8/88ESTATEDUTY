
import React, { useState } from 'react';
import { 
  ChevronRight, ArrowRight, CheckCircle2, ShieldCheck, 
  Mail, User, Phone, Briefcase, Landmark, Info, Sparkles,
  Calendar, Clock, Shield
} from 'lucide-react';
import { LeadData } from '../types';

interface OnboardingFlowProps {
  onComplete: (data: LeadData) => void;
  codeId: string;
}

const OnboardingFlow: React.FC<OnboardingFlowProps> = ({ onComplete, codeId }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    firstName: '',
    email: '',
    mobile: '',
    interest: 'Estate Planning',
    consentGiven: false
  });

  const handleNext = () => setStep(s => s + 1);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.firstName || !formData.email || !formData.consentGiven) return;

    const lead: LeadData = {
      id: crypto.randomUUID(),
      ...formData,
      timestamp: new Date().toISOString(),
      codeId: codeId
    };

    // Save to simulated lead DB in localStorage
    const storedLeads = JSON.parse(localStorage.getItem('88WM_LEADS') || '[]');
    localStorage.setItem('88WM_LEADS', JSON.stringify([...storedLeads, lead]));

    handleNext();
  };

  const renderStep1 = () => (
    <div className="animate-in fade-in slide-in-from-bottom-8 duration-700 max-w-2xl mx-auto text-center">
      <div className="w-24 h-24 bg-emerald-600 rounded-3xl flex items-center justify-center mx-auto mb-10 shadow-2xl shadow-emerald-500/20 rotate-3">
        <Sparkles size={40} className="text-white" />
      </div>
      <h1 className="text-4xl font-black text-slate-950 uppercase tracking-tighter mb-6 leading-tight">
        Welcome to the <span className="text-emerald-600">88 Wealth</span> <br/>Professional Suite
      </h1>
      <p className="text-slate-500 text-lg font-medium leading-relaxed mb-12">
        You've unlocked a sophisticated environment designed for complex estate planning, 
        agricultural property valuation, and distribution analysis. Let's get you set up.
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12 text-left">
        {[
          { icon: Landmark, title: "Estate Duty", desc: "SARS-aligned calculators." },
          { icon: ShieldCheck, title: "CGT & Fees", desc: "Statutory fee analysis." },
          { icon: CheckCircle2, title: "Distributions", desc: "Clean, visual reports." },
        ].map((item, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
            <item.icon size={20} className="text-emerald-600 mb-3" />
            <h4 className="text-xs font-black uppercase tracking-widest text-slate-800 mb-1">{item.title}</h4>
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tight">{item.desc}</p>
          </div>
        ))}
      </div>

      <button
        onClick={handleNext}
        className="group bg-slate-950 hover:bg-slate-800 text-white px-10 py-5 rounded-2xl font-black uppercase tracking-widest flex items-center gap-3 mx-auto transition-all shadow-xl shadow-slate-900/20"
      >
        Continue <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
      </button>
    </div>
  );

  const renderStep2 = () => (
    <div className="animate-in fade-in slide-in-from-right-8 duration-500 max-w-md mx-auto">
      <div className="mb-10 text-center">
        <h2 className="text-2xl font-black text-slate-950 uppercase tracking-tight mb-2">Personalize Your Experience</h2>
        <p className="text-slate-500 text-sm font-medium uppercase tracking-widest">Lead Capture & Compliance Protocol</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="space-y-1.5">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">First Name (Required)</label>
          <div className="relative">
            <User size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" />
            <input
              required
              type="text"
              value={formData.firstName}
              onChange={e => setFormData({...formData, firstName: e.target.value})}
              className="w-full bg-white border-2 border-slate-100 rounded-2xl py-4 pl-12 pr-4 text-slate-950 font-bold focus:outline-none focus:border-emerald-500 transition-all shadow-sm"
              placeholder="Your Name"
            />
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Email Address (Required)</label>
          <div className="relative">
            <Mail size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" />
            <input
              required
              type="email"
              value={formData.email}
              onChange={e => setFormData({...formData, email: e.target.value})}
              className="w-full bg-white border-2 border-slate-100 rounded-2xl py-4 pl-12 pr-4 text-slate-950 font-bold focus:outline-none focus:border-emerald-500 transition-all shadow-sm"
              placeholder="email@example.com"
            />
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Mobile Number (Optional)</label>
          <div className="relative">
            <Phone size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" />
            <input
              type="tel"
              value={formData.mobile}
              onChange={e => setFormData({...formData, mobile: e.target.value})}
              className="w-full bg-white border-2 border-slate-100 rounded-2xl py-4 pl-12 pr-4 text-slate-950 font-bold focus:outline-none focus:border-emerald-500 transition-all shadow-sm"
              placeholder="+27..."
            />
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">What are you most interested in?</label>
          <div className="relative">
            <Briefcase size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" />
            <select
              value={formData.interest}
              onChange={e => setFormData({...formData, interest: e.target.value})}
              className="w-full bg-white border-2 border-slate-100 rounded-2xl py-4 pl-12 pr-4 text-slate-950 font-bold appearance-none focus:outline-none focus:border-emerald-500 transition-all shadow-sm"
            >
              <option value="Savings">Savings</option>
              <option value="Retirement">Retirement</option>
              <option value="Investments">Investments</option>
              <option value="Risk">Risk</option>
              <option value="Estate Planning">Estate Planning</option>
            </select>
          </div>
        </div>

        <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100 space-y-4 shadow-inner">
          <div className="flex items-center gap-2 mb-2 text-indigo-600">
             <Shield size={16} />
             <h4 className="text-[10px] font-black uppercase tracking-widest">POPIA Data Protocol</h4>
          </div>
          <label className="flex items-start gap-4 cursor-pointer group">
            <input
              type="checkbox"
              required
              checked={formData.consentGiven}
              onChange={e => setFormData({...formData, consentGiven: e.target.checked})}
              className="mt-1.5 w-5 h-5 rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
            />
            <div className="flex-1">
              <span className="text-[11px] font-bold text-slate-700 leading-relaxed block group-hover:text-slate-900 transition-colors uppercase tracking-tight">
                I hereby consent to 88 Wealth Management processing my personal information to provide financial strategy illustrations and for subsequent advisory follow-up.
              </span>
              <p className="text-[9px] text-slate-400 mt-2 leading-relaxed italic">
                You confirm that you are over 18 and have read our Privacy Policy. Data will be handled in terms of the Protection of Personal Information Act, No 4 of 2013.
              </p>
            </div>
          </label>
        </div>

        <button
          type="submit"
          disabled={!formData.consentGiven}
          className="w-full bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-200 disabled:text-slate-400 text-slate-950 font-black uppercase tracking-widest py-5 rounded-2xl transition-all shadow-xl shadow-emerald-500/20 flex items-center justify-center gap-3"
        >
          Proceed to Dashboard <ArrowRight size={18} />
        </button>
      </form>
    </div>
  );

  const renderStep3 = () => (
    <div className="animate-in fade-in zoom-in-95 duration-700 max-w-xl mx-auto text-center">
      <div className="w-24 h-24 bg-indigo-600 rounded-full flex items-center justify-center mx-auto mb-10 shadow-2xl shadow-indigo-500/20">
        <CheckCircle2 size={48} className="text-white" />
      </div>
      <h2 className="text-4xl font-black text-slate-950 uppercase tracking-tighter mb-4 leading-tight">
        Thank You, {formData.firstName.split(' ')[0]}!
      </h2>
      <p className="text-slate-500 text-lg font-medium leading-relaxed mb-12">
        Your professional profile has been securely synchronized. A qualified advisor will review 
        your interests in {formData.interest} within 24 business hours.
      </p>

      <div className="space-y-4 mb-12">
        <button className="w-full bg-slate-950 hover:bg-slate-800 text-white py-5 rounded-2xl font-black uppercase tracking-widest flex items-center justify-center gap-4 transition-all group">
          <Calendar size={20} className="text-emerald-400" />
          Schedule Advisory Session
          <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
        </button>
        <button
          onClick={() => onComplete(formData as any)}
          className="w-full bg-white hover:bg-slate-50 text-slate-950 border-2 border-slate-100 py-5 rounded-2xl font-black uppercase tracking-widest flex items-center justify-center gap-4 transition-all"
        >
          <Clock size={20} className="text-slate-400" />
          Begin Illustration
        </button>
      </div>

      <div className="flex items-center justify-center gap-2 text-slate-400">
        <Info size={14} />
        <span className="text-[9px] font-black uppercase tracking-widest">Compliance-Verified Session</span>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6 relative overflow-hidden font-sans">
      {/* Abstract Background Elements */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none opacity-20">
        <div className="absolute top-[-20%] left-[-10%] w-[800px] h-[800px] bg-emerald-100 rounded-full blur-[160px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[600px] h-[600px] bg-indigo-100 rounded-full blur-[140px]" />
      </div>

      {/* Progress Indicator */}
      <div className="absolute top-12 left-1/2 -translate-x-1/2 flex items-center gap-3">
        {[1, 2, 3].map(i => (
          <div 
            key={i} 
            className={`h-1 rounded-full transition-all duration-500 ${
              step >= i ? 'w-12 bg-emerald-600' : 'w-6 bg-slate-200'
            }`} 
          />
        ))}
      </div>

      <div className="w-full max-w-4xl relative z-10">
        {step === 1 && renderStep1()}
        {step === 2 && renderStep2()}
        {step === 3 && renderStep3()}
      </div>
    </div>
  );
};

export default OnboardingFlow;

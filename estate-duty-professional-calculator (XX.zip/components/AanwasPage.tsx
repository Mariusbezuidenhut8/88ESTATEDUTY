
import React from 'react';
import { AanwasPageState, SpouseAccrualState } from '../types';
import { Scale, TrendingUp, MinusCircle, Calculator, Info, Calendar, Percent } from 'lucide-react';

interface AanwasPageProps {
  clientName: string;
  aanwasState: AanwasPageState;
  setAanwasState: React.Dispatch<React.SetStateAction<AanwasPageState>>;
}

const AanwasPage: React.FC<AanwasPageProps> = ({ clientName, aanwasState, setAanwasState }) => {
  const formatCurrency = (num: number) => {
    return num.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 });
  };

  const handleValueChange = (party: 'husband' | 'wife', field: keyof SpouseAccrualState, val: string) => {
    // Strip non-numeric characters but keep the decimal point
    const numericVal = val.replace(/[^0-9.]/g, '');
    
    // Check if the value is empty to allow clearing the field
    if (numericVal === '') {
      setAanwasState(prev => ({
        ...prev,
        [party]: { ...prev[party], [field]: 0 }
      }));
      return;
    }

    // Parse to float. We don't use parseInt because we might need cents/decimals
    const parsed = parseFloat(numericVal);
    if (!isNaN(parsed)) {
      setAanwasState(prev => ({
        ...prev,
        [party]: { ...prev[party], [field]: parsed }
      }));
    }
  };

  const handleGlobalChange = (field: 'cpiRate' | 'term', val: string) => {
    const numericVal = val.replace(/[^0-9.]/g, '');
    if (numericVal === '') {
      setAanwasState(prev => ({ ...prev, [field]: 0 }));
      return;
    }
    const parsed = parseFloat(numericVal);
    if (!isNaN(parsed)) {
      setAanwasState(prev => ({ ...prev, [field]: parsed }));
    }
  };

  const husbandCurrentNet = aanwasState.husband.currentAssets - aanwasState.husband.liabilities - aanwasState.husband.excludedAssets;
  const husbandRevaluedInitial = aanwasState.husband.initialValue * Math.pow(1 + aanwasState.cpiRate / 100, aanwasState.term);
  const husbandAccrual = Math.max(0, husbandCurrentNet - husbandRevaluedInitial);

  const wifeCurrentNet = aanwasState.wife.currentAssets - aanwasState.wife.liabilities - aanwasState.wife.excludedAssets;
  const wifeRevaluedInitial = aanwasState.wife.initialValue * Math.pow(1 + aanwasState.cpiRate / 100, aanwasState.term);
  const wifeAccrual = Math.max(0, wifeCurrentNet - wifeRevaluedInitial);

  const distributableAccrual = Math.abs(husbandAccrual - wifeAccrual) / 2;

  const InputRow = ({ label, husbandVal, wifeVal, field, icon: Icon }: { label: string, husbandVal: number, wifeVal: number, field: keyof SpouseAccrualState, icon?: any }) => (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-2 md:gap-4 items-center py-5 border-b border-slate-100 group transition-colors hover:bg-slate-50/30">
      <div className="flex items-center gap-3 px-2">
        {Icon && <Icon size={18} className="text-slate-400 group-hover:text-indigo-500 transition-colors" />}
        <span className="text-slate-600 font-black uppercase text-[10px] tracking-widest">{label}</span>
      </div>
      <div className="relative">
        <span className="absolute left-2 top-0 -translate-y-1/2 bg-blue-600 text-white text-[7px] font-black px-1.5 py-0.5 rounded md:hidden uppercase tracking-widest z-10 shadow-sm">Husband</span>
        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300 font-mono text-xs font-bold">R</span>
        <input
          type="text"
          inputMode="numeric"
          // CRITICAL: Using String() instead of toLocaleString ensures that typing is not interrupted by reformatting
          value={husbandVal === 0 ? '' : husbandVal.toString()}
          onChange={(e) => handleValueChange('husband', field, e.target.value)}
          placeholder="0"
          className="w-full bg-white border border-slate-200 rounded-xl pl-8 pr-4 py-3 text-right font-mono font-black text-slate-800 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all shadow-sm group-hover:border-blue-200"
        />
      </div>
      <div className="relative mt-2 md:mt-0">
        <span className="absolute left-2 top-0 -translate-y-1/2 bg-orange-600 text-white text-[7px] font-black px-1.5 py-0.5 rounded md:hidden uppercase tracking-widest z-10 shadow-sm">Wife</span>
        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300 font-mono text-xs font-bold">R</span>
        <input
          type="text"
          inputMode="numeric"
          value={wifeVal === 0 ? '' : wifeVal.toString()}
          onChange={(e) => handleValueChange('wife', field, e.target.value)}
          placeholder="0"
          className="w-full bg-white border border-slate-200 rounded-xl pl-8 pr-4 py-3 text-right font-mono font-black text-slate-800 focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none transition-all shadow-sm group-hover:border-orange-200"
        />
      </div>
    </div>
  );

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-32">
      <div className="bg-slate-800 rounded-xl p-6 shadow-lg border-b-4 border-slate-600 text-white flex justify-between items-center">
        <div>
          <h2 className="text-lg md:text-2xl font-black uppercase tracking-tight">Married Out of Community</h2>
          <p className="text-slate-400 text-[10px] font-medium uppercase tracking-widest mt-1">Accrual Calculation Analysis (Aanwas)</p>
        </div>
        <div className="text-right hidden sm:block">
          <span className="text-slate-400 font-bold uppercase text-[10px] block tracking-widest mb-1">Estate</span>
          <span className="text-xl font-black uppercase border-b-2 border-slate-500/30 pb-1">{clientName || 'Unknown'}</span>
        </div>
      </div>

      <div className="bg-white rounded-3xl shadow-xl border border-slate-200 overflow-hidden">
        <div className="hidden md:grid grid-cols-1 md:grid-cols-3 gap-6 bg-slate-900 p-5 text-white text-center font-black uppercase text-[11px] tracking-[0.2em] shadow-inner">
          <div className="text-left px-4">Description</div>
          <div className="bg-blue-600 rounded-lg py-2 shadow-lg shadow-blue-900/40 border border-blue-500">Husband</div>
          <div className="bg-orange-600 rounded-lg py-2 shadow-lg shadow-orange-900/40 border border-orange-500">Wife</div>
        </div>

        <div className="p-4 md:p-8 space-y-1">
          <InputRow label="Initial Value" husbandVal={aanwasState.husband.initialValue} wifeVal={aanwasState.wife.initialValue} field="initialValue" />
          <InputRow label="Current Assets" husbandVal={aanwasState.husband.currentAssets} wifeVal={aanwasState.wife.currentAssets} field="currentAssets" icon={TrendingUp} />
          <InputRow label="Minus: Liabilities" husbandVal={aanwasState.husband.liabilities} wifeVal={aanwasState.wife.liabilities} field="liabilities" icon={MinusCircle} />
          <InputRow label="Minus: Exclusions" husbandVal={aanwasState.husband.excludedAssets} wifeVal={aanwasState.wife.excludedAssets} field="excludedAssets" icon={Scale} />

          <div className="grid grid-cols-1 md:grid-cols-3 gap-2 md:gap-4 items-center py-8 border-y border-slate-100 bg-slate-50/50 -mx-4 md:-mx-8 px-4 md:px-8 mt-4">
            <span className="text-slate-900 font-black uppercase text-xs tracking-tight">Current Net Accrual Value</span>
            <div className="text-right font-mono font-black text-blue-700 text-lg md:text-2xl">
               <span className="text-[8px] md:hidden mr-2 text-slate-400 font-bold uppercase tracking-widest">Husband:</span>
               R {formatCurrency(husbandCurrentNet)}
            </div>
            <div className="text-right font-mono font-black text-orange-700 text-lg md:text-2xl">
               <span className="text-[8px] md:hidden mr-2 text-slate-400 font-bold uppercase tracking-widest">Wife:</span>
               R {formatCurrency(wifeCurrentNet)}
            </div>
          </div>

          <div className="py-8 md:py-12 space-y-8">
            <div className="flex flex-col lg:flex-row items-stretch lg:items-center gap-6 bg-slate-100/50 p-6 md:p-8 rounded-3xl border border-slate-200">
              <div className="flex-1 flex items-center gap-4 bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
                <div className="p-3 bg-indigo-50 rounded-xl text-indigo-600 shadow-inner"><Percent size={20}/></div>
                <div className="flex-1">
                  <span className="text-[9px] font-black text-slate-400 block tracking-[0.2em] uppercase mb-1">CPI Rate (Inflation)</span>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      inputMode="decimal"
                      value={aanwasState.cpiRate.toString()}
                      onChange={(e) => handleGlobalChange('cpiRate', e.target.value)}
                      className="w-full bg-transparent outline-none font-mono font-black text-slate-800 text-lg"
                    />
                    <span className="text-slate-400 font-black text-sm">%</span>
                  </div>
                </div>
              </div>
              <div className="flex-1 flex items-center gap-4 bg-white p-4 rounded-2xl border border-slate-100 shadow-sm">
                <div className="p-3 bg-emerald-50 rounded-xl text-emerald-600 shadow-inner"><Calendar size={20}/></div>
                <div className="flex-1">
                  <span className="text-[9px] font-black text-slate-400 block tracking-[0.2em] uppercase mb-1">Marriage Term</span>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      inputMode="numeric"
                      value={aanwasState.term.toString()}
                      onChange={(e) => handleGlobalChange('term', e.target.value)}
                      className="w-full bg-transparent outline-none font-mono font-black text-slate-800 text-lg"
                    />
                    <span className="text-slate-400 font-black text-xs uppercase tracking-widest">Years</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-2 md:gap-4 items-center px-4">
              <span className="text-slate-400 font-black uppercase text-[9px] md:text-[10px] tracking-widest">Revalued Initial Value (Indexed)</span>
              <div className="text-right font-mono font-bold text-slate-500 text-sm md:text-lg">R {formatCurrency(husbandRevaluedInitial)}</div>
              <div className="text-right font-mono font-bold text-slate-500 text-sm md:text-lg">R {formatCurrency(wifeRevaluedInitial)}</div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-2 md:gap-4 items-center py-6 md:py-8 bg-slate-900 rounded-3xl px-6 md:px-10 text-white shadow-2xl shadow-slate-900/30">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-white/10 rounded-2xl">
                <Calculator size={20} className="text-emerald-400" />
              </div>
              <span className="font-black uppercase text-[10px] md:text-xs tracking-[0.2em]">Net Accrual</span>
            </div>
            <div className="text-right font-mono font-black text-xl md:text-3xl text-white">
               <span className="text-[8px] md:hidden mr-2 text-slate-500 font-bold uppercase tracking-widest">H Accrual:</span>
               R {formatCurrency(husbandAccrual)}
            </div>
            <div className="text-right font-mono font-black text-xl md:text-3xl text-white">
               <span className="text-[8px] md:hidden mr-2 text-slate-500 font-bold uppercase tracking-widest">W Accrual:</span>
               R {formatCurrency(wifeAccrual)}
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-[3rem] border-2 border-slate-100 p-8 md:p-14 flex flex-col items-center justify-center shadow-[0_35px_60px_-15px_rgba(0,0,0,0.1)] relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-[0.03] pointer-events-none scale-150">
          <Scale size={200} />
        </div>
        <div className="text-slate-400 text-[10px] md:text-xs font-black uppercase tracking-[0.5em] mb-6 text-center">
          Distributable Accrual Claim
        </div>
        <div className="text-5xl md:text-8xl font-mono font-black text-slate-900 drop-shadow-sm text-center tracking-tighter">
          R {formatCurrency(distributableAccrual)}
        </div>
        <div className="mt-8 md:mt-12 flex items-center gap-4 bg-emerald-50 px-8 md:px-12 py-4 rounded-full border border-emerald-100 shadow-sm animate-pulse">
           <Info size={16} className="text-emerald-500 shrink-0" />
           <span className="text-emerald-800 font-black uppercase text-[10px] md:text-sm tracking-widest text-center">
              Settlement Value (50% of difference)
           </span>
        </div>
      </div>
    </div>
  );
};

export default AanwasPage;

import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, Key, Plus, Trash2, Calendar, 
  Users, CheckCircle, XCircle, RefreshCw, Eye, UserCheck, Mail, Phone, Info
} from 'lucide-react';
import { PermissionCode, AccessRole, LeadData } from '../types';

const AdminPage: React.FC = () => {
  const [codes, setCodes] = useState<PermissionCode[]>([]);
  const [leads, setLeads] = useState<LeadData[]>([]);
  const [newCodeRole, setNewCodeRole] = useState<AccessRole>('CLIENT');
  const [newCodeMaxUses, setNewCodeMaxUses] = useState(1);
  const [newCodeExpiry, setNewCodeExpiry] = useState('');

  useEffect(() => {
    const storedCodes = localStorage.getItem('88WM_CODES');
    if (storedCodes) setCodes(JSON.parse(storedCodes));
    
    const storedLeads = localStorage.getItem('88WM_LEADS');
    if (storedLeads) setLeads(JSON.parse(storedLeads));
  }, []);

  const saveCodes = (updated: PermissionCode[]) => {
    setCodes(updated);
    localStorage.setItem('88WM_CODES', JSON.stringify(updated));
  };

  const generateCode = () => {
    const randomStr = () => Math.random().toString(36).substring(2, 6).toUpperCase();
    const newCode: PermissionCode = {
      id: crypto.randomUUID(),
      code: `88WM-${randomStr()}-${randomStr()}`,
      role: newCodeRole,
      createdAt: new Date().toISOString(),
      expiresAt: newCodeExpiry ? new Date(newCodeExpiry).toISOString() : null,
      maxUses: newCodeMaxUses,
      currentUses: 0,
      isActive: true
    };
    saveCodes([...codes, newCode]);
  };

  const deleteCode = (id: string) => {
    saveCodes(codes.filter((c) => c.id !== id));
  };

  const toggleStatus = (id: string) => {
    saveCodes(codes.map((c) => c.id === id ? { ...c, isActive: !c.isActive } : c));
  };

  const clearLeads = () => {
    setLeads([]);
    localStorage.removeItem('88WM_LEADS');
  };

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700 pb-32">
      <div className="bg-slate-900 rounded-3xl p-10 text-white relative overflow-hidden shadow-2xl border-b-8 border-emerald-600">
        <div className="absolute top-0 right-0 p-10 opacity-10 pointer-events-none">
          <ShieldAlert size={160} />
        </div>
        <div className="relative z-10">
          <h1 className="text-4xl font-black uppercase tracking-tighter mb-2">Access Management</h1>
          <p className="text-slate-400 text-sm font-bold uppercase tracking-widest">Generate and control application permission codes</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Create New Code Card */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-8 space-y-6">
          <div className="flex items-center gap-3 mb-2">
             <Key className="text-emerald-500" size={24} />
             <h3 className="text-sm font-black uppercase tracking-widest text-slate-800">Generate Code</h3>
          </div>

          <div className="space-y-4">
             <div>
                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest block mb-2">Assigned Role</label>
                <div className="grid grid-cols-3 gap-2">
                   {(['VIEWER', 'CLIENT', 'ADMIN', 'GUEST', 'PROSPECT'] as AccessRole[]).map((role) => (
                      <button
                        key={role}
                        onClick={() => setNewCodeRole(role)}
                        className={`py-2 px-1 rounded-xl text-[8px] font-black transition-all ${
                          newCodeRole === role ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/20' : 'bg-slate-100 text-slate-400 hover:bg-slate-200'
                        }`}
                      >
                        {role}
                      </button>
                   ))}
                </div>
             </div>

             <div>
                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest block mb-2">Max Usage</label>
                <input 
                   type="number" 
                   value={newCodeMaxUses} 
                   onChange={(e) => setNewCodeMaxUses(parseInt(e.target.value) || 1)}
                   className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-900 focus:outline-none focus:border-emerald-500"
                />
             </div>

             <div>
                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest block mb-2">Expiration Date (Optional)</label>
                <input 
                   type="date" 
                   value={newCodeExpiry} 
                   onChange={(e) => setNewCodeExpiry(e.target.value)}
                   className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-900 focus:outline-none focus:border-emerald-500"
                />
             </div>

             <button 
                onClick={generateCode}
                className="w-full bg-slate-950 text-white font-black uppercase tracking-widest py-4 rounded-2xl flex items-center justify-center gap-2 hover:bg-slate-800 transition-all shadow-xl shadow-slate-900/10"
             >
                <Plus size={18} /> Create Access Code
             </button>
          </div>
        </div>

        {/* Captured Leads Summary */}
        <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-200 shadow-sm p-8 flex flex-col">
           <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-3">
                 <Users className="text-indigo-500" size={24} />
                 <h3 className="text-sm font-black uppercase tracking-widest text-slate-800">Captured Leads</h3>
              </div>
              <button 
                onClick={clearLeads}
                className="text-[9px] font-black uppercase text-red-400 hover:text-red-600 tracking-widest transition-colors"
              >
                Clear Database
              </button>
           </div>

           <div className="flex-1 overflow-y-auto max-h-[400px] space-y-4 pr-2">
              {leads.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-300 py-20">
                   <Users size={48} className="mb-4 opacity-20" />
                   <span className="text-xs font-black uppercase tracking-[0.2em]">No Lead Data Captured Yet</span>
                </div>
              ) : (
                leads.map((lead) => (
                  <div key={lead.id} className="bg-slate-50 border border-slate-100 p-5 rounded-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                     <div className="flex items-center gap-4">
                        <div className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center font-black text-xs">
                           {lead.firstName.substring(0, 1).toUpperCase()}
                        </div>
                        <div>
                           <h4 className="text-sm font-black text-slate-900 uppercase tracking-tight">{lead.firstName}</h4>
                           <div className="flex items-center gap-3 mt-1">
                              <span className="flex items-center gap-1 text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                                 <Mail size={10} /> {lead.email}
                              </span>
                              {lead.mobile && (
                                <span className="flex items-center gap-1 text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                                   <Phone size={10} /> {lead.mobile}
                                </span>
                              )}
                           </div>
                        </div>
                     </div>
                     <div className="text-right">
                        <span className="inline-block px-2 py-1 bg-indigo-600 text-white text-[8px] font-black uppercase tracking-widest rounded mb-1">
                           {lead.interest}
                        </span>
                        <p className="text-[8px] text-slate-400 font-bold uppercase tracking-widest">
                           {new Date(lead.timestamp).toLocaleDateString()} @ {new Date(lead.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                        </p>
                     </div>
                  </div>
                ))
              )}
           </div>
        </div>
      </div>

      {/* Active Codes List */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
         <div className="p-8 border-b border-slate-100 flex justify-between items-center">
            <h3 className="text-sm font-black uppercase tracking-widest text-slate-800 flex items-center gap-3">
               <RefreshCw size={18} className="text-emerald-500" /> Current Access Codes
            </h3>
            <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{codes.length} Active Strings</span>
         </div>
         <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
               <thead className="bg-slate-50 text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] border-b border-slate-100">
                  <tr>
                     <th className="px-8 py-4">Security Code</th>
                     <th className="px-8 py-4">Role</th>
                     <th className="px-8 py-4">Status</th>
                     <th className="px-8 py-4">Usage</th>
                     <th className="px-8 py-4">Expires</th>
                     <th className="px-8 py-4 text-right">Actions</th>
                  </tr>
               </thead>
               <tbody className="divide-y divide-slate-50">
                  {codes.map((code) => (
                     <tr key={code.id} className="group hover:bg-slate-50/50 transition-colors">
                        <td className="px-8 py-5">
                           <div className="flex items-center gap-2">
                              <span className="font-mono font-black text-slate-900 tracking-wider bg-slate-100 px-3 py-1 rounded text-xs select-all">
                                 {code.code}
                              </span>
                           </div>
                        </td>
                        <td className="px-8 py-5">
                           <span className={`text-[9px] font-black uppercase tracking-widest px-2 py-1 rounded ${
                              code.role === 'ADMIN' ? 'bg-indigo-100 text-indigo-700' :
                              code.role === 'VIEWER' ? 'bg-slate-200 text-slate-600' :
                              'bg-emerald-100 text-emerald-700'
                           }`}>
                              {code.role}
                           </span>
                        </td>
                        <td className="px-8 py-5">
                           {code.isActive ? (
                              <span className="flex items-center gap-1.5 text-emerald-600 font-bold text-[9px] uppercase tracking-widest">
                                 <CheckCircle size={12} /> Active
                              </span>
                           ) : (
                              <span className="flex items-center gap-1.5 text-red-400 font-bold text-[9px] uppercase tracking-widest">
                                 <XCircle size={12} /> Revoked
                              </span>
                           )}
                        </td>
                        <td className="px-8 py-5">
                           <div className="w-24 bg-slate-100 h-1.5 rounded-full overflow-hidden mb-1">
                              <div 
                                 className="bg-emerald-500 h-full transition-all duration-1000" 
                                 style={{ width: `${Math.min(100, (code.currentUses / code.maxUses) * 100)}%` }} 
                              />
                           </div>
                           <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">
                              {code.currentUses} / {code.maxUses} Uses
                           </span>
                        </td>
                        <td className="px-8 py-5">
                           <span className="text-[9px] font-bold text-slate-600 uppercase tracking-widest">
                              {code.expiresAt ? new Date(code.expiresAt).toLocaleDateString() : 'NEVER'}
                           </span>
                        </td>
                        <td className="px-8 py-5 text-right space-x-2">
                           <button 
                              onClick={() => toggleStatus(code.id)}
                              className={`p-2 rounded-lg transition-colors ${code.isActive ? 'text-slate-300 hover:text-orange-500 hover:bg-orange-50' : 'text-emerald-500 hover:bg-emerald-50'}`}
                              title={code.isActive ? 'Deactivate' : 'Activate'}
                           >
                              {code.isActive ? <XCircle size={16}/> : <CheckCircle size={16}/>}
                           </button>
                           <button 
                              onClick={() => deleteCode(code.id)}
                              className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                              title="Delete"
                           >
                              <Trash2 size={16} />
                           </button>
                        </td>
                     </tr>
                  ))}
               </tbody>
            </table>
            {codes.length === 0 && (
               <div className="p-20 text-center flex flex-col items-center justify-center space-y-4">
                  <Eye size={48} className="text-slate-100" />
                  <p className="text-xs font-black text-slate-300 uppercase tracking-widest">No Security Strings Defined</p>
               </div>
            )}
         </div>
      </div>
    </div>
  );
};

export default AdminPage;
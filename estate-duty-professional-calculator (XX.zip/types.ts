
export type AccessRole = 'VIEWER' | 'CLIENT' | 'ADMIN' | 'GUEST' | 'PROSPECT';

export interface PermissionCode {
  id: string;
  code: string;
  role: AccessRole;
  createdAt: string;
  expiresAt: string | null;
  maxUses: number;
  currentUses: number;
  isActive: boolean;
}

export interface UsageLog {
  id: string;
  codeId: string;
  timestamp: string;
  action: 'LOGIN' | 'REVOKE' | 'EXPIRE';
  role: AccessRole;
}

export interface AccessSession {
  token: string;
  role: AccessRole;
  expiresAt: number;
  onboardingComplete?: boolean;
}

export interface LeadData {
  id: string;
  firstName: string;
  email: string;
  mobile?: string;
  interest?: string;
  consentGiven: boolean;
  timestamp: string;
  codeId: string;
}

export interface Farm {
  id: string;
  name: string;
  marketValue: number;
  baseCost: number;
}

export interface LivestockState {
  cattle: number;
  sheep: number;
  game: number;
}

export interface MiscellaneousState {
  misc: number;
  implements: number;
  crops: number;
}

export interface BusinessInterestsState {
  soleProprietorship: number;
  soleProprietorshipBase: number;
  partnership: number;
  partnershipBase: number;
  ccInterest: number;
  ccInterestBase: number;
  companyShares: number;
  companySharesBase: number;
}

export interface ResidentialState {
  property1: number;
  property1Name: string;
  property1Base: number;
  property2: number;
  property2Name: string;
  property2Base: number;
  holidayHome: number;
  holidayHomeBase: number;
  householdEffects: number;
}

export interface VehicleState {
  v1: { name: string, value: number };
  v2: { name: string, value: number };
  v3: { name: string, value: number };
}

export interface CashState {
  onCall: number;
  moneyMarket: number;
}

export interface InvestmentState {
  shares: number;
  sharesBase: number;
  unitTrusts: number;
  unitTrustsBase: number;
}

export interface LoanAccountState {
  creditLoans: number;
}

export interface OtherState {
  o1: { name: string, value: number };
  o2: { name: string, value: number };
  o3: { name: string, value: number };
  o4: { name: string, value: number };
  o5: { name: string, value: number };
}

export interface PolicyState {
  spouse: number;
  thirdParties: number;
  estate: number;
  cashValues3rd: number;
  ceded: number;
  deathValuesSpouse: number;
  deathValues3rd: number;
}

export interface DeductionState {
  mastersFees: number;
  funeral: number;
  executorsFee: number;
  overdraft: number;
  liabilities: number;
  mortgage: number;
  cgt: number;
  debitLoans: number;
}

export interface Art4qState {
  usufruct: number;
  wife: number;
  husband: number;
  policies: number;
  vehicles: number;
  miscDescription: string;
  miscValue: number;
  residential: number;
  household: number;
  other: number;
}

export interface ExecutorsFeesState {
  feeRate: number;
  whatIfRate: number;
}

export interface CGTAsset {
  id: string;
  description: string;
  marketValue: number;
  baseCost: number;
}

export interface CGTState {
  primaryResidenceExclusion: number;
  otherAssets: CGTAsset[];
  annualExclusion: number;
  rollOverExemption: number;
  inclusionRate: number;
  taxRate: number;
  rule20: {
    marketValueLessImprovements: number;
    discount: number;
    inclusionRate: number;
    taxRate: number;
  };
}

export interface CashPageState {
  otherCash: number;
  cashLegacies: number;
}

export interface Legacy {
  id: string;
  description: string;
  value: number;
}

export interface ResiduePageState {
  spouseLegacy: number;
  thirdPartyLegacies: Legacy[];
}

export interface SpouseAccrualState {
  initialValue: number;
  currentAssets: number;
  liabilities: number;
  excludedAssets: number;
}

export interface AanwasPageState {
  husband: SpouseAccrualState;
  wife: SpouseAccrualState;
  cpiRate: number;
  term: number;
}

export interface AppropriationParty {
  id: string;
  name: string;
  portion: number;
}

export interface AppropriationPageState {
  parties: AppropriationParty[];
}

export enum Page {
  EstateDuty = 'ESTATE DUTY',
  ExecutorsFees = 'EXECUTORS FEES',
  Cash = 'CASH',
  CGT = 'CGT',
  Remains = 'REMAINS',
  Aanwas = 'AANWAS',
  Appropriation = 'APPROPRIATION',
  Summary = 'SUMMARY',
  UserManual = 'USER MANUAL',
  Admin = 'ADMIN PANEL'
}

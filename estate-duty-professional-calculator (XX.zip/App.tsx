
import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import EstateDutyPage from './components/EstateDutyPage';
import ExecutorsFeesPage from './components/ExecutorsFeesPage';
import CGTPage from './components/CGTPage';
import CashPage from './components/CashPage';
import ResiduePage from './components/ResiduePage';
import AanwasPage from './components/AanwasPage';
import AppropriationPage from './components/AppropriationPage';
import SummaryPage from './components/SummaryPage';
import UserManualPage from './components/UserManualPage';
import AdminPage from './components/AdminPage';
import AccessScreen from './components/AccessScreen';
import OnboardingFlow from './components/OnboardingFlow';
import ComplianceModal from './components/ComplianceModal';
import { Lock } from 'lucide-react';
import { 
  Page, 
  Farm, 
  LivestockState, 
  MiscellaneousState, 
  BusinessInterestsState, 
  ResidentialState,
  VehicleState,
  CashState,
  InvestmentState,
  LoanAccountState,
  OtherState,
  PolicyState,
  DeductionState,
  Art4qState,
  ExecutorsFeesState,
  CGTState,
  CashPageState,
  ResiduePageState,
  AanwasPageState,
  AppropriationPageState,
  AccessSession,
  LeadData
} from './types';

const App: React.FC = () => {
  const [session, setSession] = useState<AccessSession | null>(null);
  const [complianceMet, setComplianceMet] = useState(false);
  const [currentPage, setCurrentPage] = useState<Page>(Page.EstateDuty);
  const [clientName, setClientName] = useState('JOHN SMITH');
  
  // Persistence Check
  useEffect(() => {
    const stored = localStorage.getItem('88WM_SESSION');
    if (stored) {
      const parsed: AccessSession = JSON.parse(stored);
      if (parsed.expiresAt > Date.now()) {
        setSession(parsed);
        const met = localStorage.getItem('88WM_COMPLIANCE') === 'true';
        setComplianceMet(met);
      } else {
        localStorage.removeItem('88WM_SESSION');
        localStorage.removeItem('88WM_COMPLIANCE');
      }
    }
  }, []);

  const handleGrantAccess = (newSession: AccessSession) => {
    setSession(newSession);
    localStorage.setItem('88WM_SESSION', JSON.stringify(newSession));
  };

  const handleAcknowledgeCompliance = () => {
    setComplianceMet(true);
    localStorage.setItem('88WM_COMPLIANCE', 'true');
  };

  const handleLogout = () => {
    setSession(null);
    setComplianceMet(false);
    localStorage.removeItem('88WM_SESSION');
    localStorage.removeItem('88WM_COMPLIANCE');
  };

  const handleOnboardingComplete = (data: LeadData) => {
    if (session) {
      const updatedSession = { ...session, onboardingComplete: true };
      setSession(updatedSession);
      localStorage.setItem('88WM_SESSION', JSON.stringify(updatedSession));
      if (data.firstName) setClientName(data.firstName.toUpperCase());
    }
  };

  // State Management
  const [farms, setFarms] = useState<Farm[]>([
    { id: '1', name: 'Main Farm', marketValue: 10000000, baseCost: 0 },
    { id: '2', name: 'Secondary Farm', marketValue: 5000000, baseCost: 0 },
  ]);

  const [livestock, setLivestock] = useState<LivestockState>({ cattle: 1000000, sheep: 1000000, game: 0 });
  const [misc, setMisc] = useState<MiscellaneousState>({ misc: 1000, implements: 0, crops: 0 });
  const [business, setBusiness] = useState<BusinessInterestsState>({
    soleProprietorship: 1000, soleProprietorshipBase: 0, partnership: 0, partnershipBase: 0,
    ccInterest: 0, ccInterestBase: 0, companyShares: 0, companySharesBase: 0
  });

  const [residential, setResidential] = useState<ResidentialState>({
    property1: 1000, property1Name: 'Primary Residence', property1Base: 0, property2: 0,
    property2Name: '', property2Base: 0, holidayHome: 0, holidayHomeBase: 0, householdEffects: 0
  });

  const [vehicles, setVehicles] = useState<VehicleState>({
    v1: { name: 'SUV', value: 400000 }, v2: { name: '', value: 0 }, v3: { name: '', value: 0 }
  });

  const [cash, setCash] = useState<CashState>({ onCall: 100000, moneyMarket: 300000 });
  const [investments, setInvestments] = useState<InvestmentState>({ shares: 1000, sharesBase: 0, unitTrusts: 0, unitTrustsBase: 0 });
  const [loans, setLoans] = useState<LoanAccountState>({ creditLoans: 1000 });
  const [other, setOther] = useState<OtherState>({
    o1: { name: 'Assets inherited from spouse', value: 1000 }, o2: { name: '', value: 0 }, o3: { name: '', value: 0 }, o4: { name: '', value: 0 }, o5: { name: '', value: 0 }
  });

  const [policies, setPolicies] = useState<PolicyState>({
    spouse: 3000000, thirdParties: 4000000, estate: 2500000, cashValues3rd: 500000,
    ceded: 250000, deathValuesSpouse: 100000, deathValues3rd: 10000
  });

  const [deductions, setDeductions] = useState<DeductionState>({
    mastersFees: 600, funeral: 20000, executorsFee: 0, overdraft: 0,
    liabilities: 4000000, mortgage: 0, cgt: 0, debitLoans: 0
  });

  const [art4q, setArt4q] = useState<Art4qState>({
    usufruct: 0, wife: 0, husband: 0, policies: 3000000, vehicles: 0,
    miscDescription: '', miscValue: 0, residential: 0, household: 0, other: 0
  });

  const [art4aRebate, setArt4aRebate] = useState<number>(3500000);
  const [executorsFees, setExecutorsFees] = useState<ExecutorsFeesState>({ feeRate: 3.5, whatIfRate: 35.0 });
  const [cgt, setCgt] = useState<CGTState>({
    primaryResidenceExclusion: 2000000, otherAssets: [], annualExclusion: 300000, rollOverExemption: 0,
    inclusionRate: 40.00, taxRate: 30.00, rule20: { marketValueLessImprovements: 0, discount: 0, inclusionRate: 40.00, taxRate: 30.00 }
  });

  const [cashPageState, setCashPageState] = useState<CashPageState>({ otherCash: 0, cashLegacies: 0 });
  const [residueState, setResidueState] = useState<ResiduePageState>({ spouseLegacy: 0, thirdPartyLegacies: [] });
  const [aanwasState, setAanwasState] = useState<AanwasPageState>({
    husband: { initialValue: 0, currentAssets: 0, liabilities: 0, excludedAssets: 0 },
    wife: { initialValue: 0, currentAssets: 0, liabilities: 0, excludedAssets: 0 },
    cpiRate: 7, term: 10
  });

  const [appropriationState, setAppropriationState] = useState<AppropriationPageState>({
    parties: Array.from({length: 6}, (_, i) => ({ id: `${i+1}`, name: `Party ${i+1}`, portion: 0 }))
  });

  // Role Logic
  const isRestricted = session?.role === 'GUEST' || session?.role === 'PROSPECT' || session?.role === 'VIEWER';
  const needsOnboarding = (session?.role === 'GUEST' || session?.role === 'PROSPECT') && !session?.onboardingComplete;
  
  // Helper for SARS 20% Base Cost Rule
  const calculateGainWith20PercentRule = (proceeds: number, baseCost: number, exclusion: number = 0) => {
    // If base cost is 0, use SARS 20% rule: Proceeds - (20% of Proceeds)
    const effectiveBase = baseCost > 0 ? baseCost : (proceeds * 0.2);
    return Math.max(0, proceeds - effectiveBase - exclusion);
  };

  // Derived Calculations
  const farmGains = farms.reduce((sum, f) => sum + calculateGainWith20PercentRule(f.marketValue, f.baseCost), 0);
  const residentialGains = 
    calculateGainWith20PercentRule(residential.property1, residential.property1Base, cgt.primaryResidenceExclusion) +
    calculateGainWith20PercentRule(residential.property2, residential.property2Base) + 
    calculateGainWith20PercentRule(residential.holidayHome, residential.holidayHomeBase);
  const businessGains = 
    calculateGainWith20PercentRule(business.soleProprietorship, business.soleProprietorshipBase) + 
    calculateGainWith20PercentRule(business.partnership, business.partnershipBase) +
    calculateGainWith20PercentRule(business.ccInterest, business.ccInterestBase) + 
    calculateGainWith20PercentRule(business.companyShares, business.companySharesBase);
  const investmentGains = 
    calculateGainWith20PercentRule(investments.shares, investments.sharesBase) + 
    calculateGainWith20PercentRule(investments.unitTrusts, investments.unitTrustsBase);
  const manualGains = cgt.otherAssets.reduce((s, a) => s + calculateGainWith20PercentRule(a.marketValue, a.baseCost), 0);

  const totalGrossGain = farmGains + residentialGains + businessGains + investmentGains + manualGains;
  const totalCalculatedCGT = Math.max(0, totalGrossGain - cgt.annualExclusion) * (cgt.inclusionRate / 100) * (cgt.taxRate / 100);

  // Define comprehensive asset totals for gross estate calculation
  const totalFarms70 = farms.reduce((sum, f) => sum + (f.marketValue || 0) * 0.7, 0);
  // Fix: Explicitly cast Object.values to number[] to resolve unknown operator errors
  const totalLivestock = (Object.values(livestock) as number[]).reduce((a, b) => a + (b || 0), 0);
  const totalMisc = (Object.values(misc) as number[]).reduce((a, b) => a + (b || 0), 0);
  const totalBusiness = (business.soleProprietorship || 0) + (business.partnership || 0) + (business.ccInterest || 0) + (business.companyShares || 0);
  const totalResidential = (residential.property1 || 0) + (residential.property2 || 0) + (residential.holidayHome || 0) + (residential.householdEffects || 0);
  const totalVehicles = (vehicles.v1.value || 0) + (vehicles.v2.value || 0) + (vehicles.v3.value || 0);
  const cashFromAssets = (cash.onCall || 0) + (cash.moneyMarket || 0);
  const totalInvestments = (investments.shares || 0) + (investments.unitTrusts || 0);
  const totalLoans = (loans.creditLoans || 0);
  const totalOther = (other.o1.value || 0) + (other.o2.value || 0) + (other.o3.value || 0) + (other.o4.value || 0) + (other.o5.value || 0) + totalGrossGain;
  // Fix: Explicitly cast Object.values to number[] to resolve unknown operator errors
  const totalPolicies = (Object.values(policies) as number[]).reduce((a, b) => a + (b || 0), 0);

  const grossEstate = totalFarms70 + totalLivestock + totalMisc + totalBusiness + totalResidential + totalVehicles + cashFromAssets + totalInvestments + totalLoans + totalOther + totalPolicies;

  const husbandCurrentNet = aanwasState.husband.currentAssets - aanwasState.husband.liabilities - aanwasState.husband.excludedAssets;
  const husbandRevaluedInitial = aanwasState.husband.initialValue * Math.pow(1 + aanwasState.cpiRate / 100, aanwasState.term);
  const husbandAccrual = Math.max(0, husbandCurrentNet - husbandRevaluedInitial);
  const wifeCurrentNet = aanwasState.wife.currentAssets - aanwasState.wife.liabilities - aanwasState.wife.excludedAssets;
  const wifeRevaluedInitial = aanwasState.wife.initialValue * Math.pow(1 + aanwasState.cpiRate / 100, aanwasState.term);
  const wifeAccrual = Math.max(0, wifeCurrentNet - wifeRevaluedInitial);
  const accrualClaim = Math.abs(husbandAccrual - wifeAccrual) / 2;

  const autoExecutorsFee = (grossEstate - (policies.spouse + policies.thirdParties)) * (executorsFees.feeRate / 100);
  const totalDeductions = deductions.mastersFees + deductions.funeral + autoExecutorsFee + deductions.liabilities + totalCalculatedCGT + accrualClaim;
  const totalArt4q = (art4q.usufruct || 0) + policies.spouse + (art4q.miscValue || 0) + (art4q.residential || 0);
  const netEstate = grossEstate - totalDeductions - totalArt4q;
  const taxableEstate = Math.max(0, netEstate - art4aRebate);
  const estateDuty = taxableEstate <= 30000000 ? taxableEstate * 0.20 : (30000000 * 0.20) + ((taxableEstate - 30000000) * 0.25);

  const renderPage = () => {
    switch (currentPage) {
      case Page.EstateDuty: return <EstateDutyPage farms={farms} setFarms={setFarms} livestock={livestock} setLivestock={setLivestock} misc={misc} setMisc={setMisc} business={business} setBusiness={setBusiness} residential={residential} setResidential={setResidential} vehicles={vehicles} setVehicles={setVehicles} cash={cash} setCash={setCash} investments={investments} setInvestments={setInvestments} loans={loans} setLoans={setLoans} other={other} setOther={setOther} policies={policies} setPolicies={setPolicies} deductions={{...deductions, cgt: totalCalculatedCGT}} setDeductions={setDeductions} art4q={art4q} setArt4q={setArt4q} art4aRebate={art4aRebate} setArt4aRebate={setArt4aRebate} clientName={clientName} autoExecutorsFee={autoExecutorsFee} totalGrossGain={totalGrossGain} accrualClaim={accrualClaim} />;
      case Page.ExecutorsFees: return <ExecutorsFeesPage clientName={clientName} grossEstate={grossEstate} policies={policies} executorsFees={executorsFees} setExecutorsFees={setExecutorsFees} autoExecutorsFee={autoExecutorsFee} />;
      case Page.CGT: return <CGTPage clientName={clientName} cgt={cgt} setCgt={setCgt} farms={farms} setFarms={setFarms} business={business} setBusiness={setBusiness} residential={residential} setResidential={setResidential} investments={investments} setInvestments={setInvestments} />;
      case Page.Cash: return <CashPage clientName={clientName} cashFromAssets={cashFromAssets} estatePolicy={policies.estate} cededPolicy={policies.ceded} liabilitiesAndCosts={totalDeductions} estateDuty={estateDuty} cashPageState={cashPageState} setCashPageState={setCashPageState} />;
      case Page.Remains: return <ResiduePage clientName={clientName} netAssetsAvailable={grossEstate - totalDeductions} estateDuty={estateDuty} cashDeficit={0} residueState={residueState} setResidueState={setResidueState} />;
      case Page.Aanwas: return <AanwasPage clientName={clientName} aanwasState={aanwasState} setAanwasState={setAanwasState} />;
      case Page.Appropriation: return <AppropriationPage clientName={clientName} totalEstateDuty={estateDuty} netEstateValue={netEstate} appropriationState={appropriationState} setAppropriationState={setAppropriationState} />;
      case Page.Summary: return <SummaryPage clientName={clientName} farms={farms} livestock={livestock} misc={misc} business={business} residential={residential} vehicles={vehicles} cash={cash} investments={investments} loans={loans} other={other} policies={policies} deductions={deductions} art4q={art4q} residueState={residueState} art4aRebate={art4aRebate} autoExecutorsFee={autoExecutorsFee} totalCalculatedCGT={totalCalculatedCGT} grossEstate={grossEstate} netEstate={netEstate} taxableEstate={taxableEstate} estateDuty={estateDuty} accrualClaim={accrualClaim} />;
      case Page.UserManual: return <UserManualPage />;
      case Page.Admin: return <AdminPage />;
      default: return null;
    }
  };

  if (!session) return <AccessScreen onGrantAccess={handleGrantAccess} />;
  if (needsOnboarding) return <OnboardingFlow onComplete={handleOnboardingComplete} codeId={session.token} />;
  if (!complianceMet) return <ComplianceModal clientName={clientName} onAcknowledge={handleAcknowledgeCompliance} />;

  // Allow interaction with buttons on Summary page for viewers (Share/Print)
  const isInputPage = [Page.EstateDuty, Page.ExecutorsFees, Page.CGT, Page.Cash, Page.Remains, Page.Aanwas, Page.Appropriation].includes(currentPage);

  return (
    <Layout currentPage={currentPage} onPageChange={setCurrentPage} clientName={clientName} onClientNameChange={setClientName} role={session.role} onLogout={handleLogout}>
      <div className={isRestricted && isInputPage ? 'pointer-events-none grayscale-[50%]' : ''}>
        {renderPage()}
      </div>
      {isRestricted && (
        <div className="fixed top-24 right-10 z-50 bg-red-600 text-white px-4 py-2 rounded-full font-black text-[10px] uppercase tracking-widest shadow-xl flex items-center gap-2">
           <Lock size={14}/> Read Only Mode
        </div>
      )}
    </Layout>
  );
};

export default App;
